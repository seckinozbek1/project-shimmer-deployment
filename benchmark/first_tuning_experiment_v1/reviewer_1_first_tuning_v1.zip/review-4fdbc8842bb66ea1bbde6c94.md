# Independent semantic review

Packet: review-4fdbc8842bb66ea1bbde6c94

Review independently without consulting authored labels, split files, or transformation metadata. Return semantic judgment, exact evidence, concise reason and ambiguity/refusal separately from formatting judgment. Producer item fields: span, claims, questions, uncertainty, status, refs; one per owned alias. Auditor item fields: finding, ref_ids, reasoning, severity, confidence. Use MATCH/DIVERGENCE/OMISSION/ADDITION for fidelity; refuse with items=[] and status=refused for insufficient evidence.

```json
{
  "role": "auditor",
  "production_contract": "semantic-task-v1",
  "source_spans": [
    {
      "alias": "s0",
      "text": "Question: What was entered first?\nAnswer: CLM-A: vraxlet 60 recorded 74 flomquils (REF-1001).\nQuestion: What followed?\nAnswer: CLM-B: vraxlet 60 retained 79 flomquils (REF-1002).\nClerk note: The date is absent. When was this recorded?"
    }
  ],
  "context_only_spans": [],
  "supplied_refs": [
    "REF-1001",
    "REF-1002"
  ],
  "required_refs": [
    "REF-1001",
    "REF-1002"
  ],
  "routed_rules": [],
  "extraction": "Question: What was entered first?\nAnswer: CLM-A: vraxlet 60 recorded 74 flomquils (REF-1001).\nQuestion: What followed?\nAnswer: CLM-B: vraxlet 60 retained 79 flomquils (REF-1002).\nClerk note: The date is absent. When was this recorded?"
}
```

## Response template (pending, not a submitted review)

```json
{
  "packet_id": "review-4fdbc8842bb66ea1bbde6c94",
  "input_sha256": "4fdbc8842bb66ea1bbde6c94dbac469998ba0f9f22b45e5df9505fbb746239a4",
  "review_version": "semantic-benchmark-v2",
  "reviewer_id": null,
  "reviewer_kind": null,
  "independence_attestation": false,
  "reviewed_at": null,
  "semantic_target": null,
  "semantic_judgment": null,
  "reason_components": [],
  "rationale": null,
  "ambiguity": null,
  "formatting_judgment": "not_assessed"
}
```
