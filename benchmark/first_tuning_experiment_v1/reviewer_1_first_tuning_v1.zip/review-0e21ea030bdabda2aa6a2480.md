# Independent semantic review

Packet: review-0e21ea030bdabda2aa6a2480

Review independently without consulting authored labels, split files, or transformation metadata. Return semantic judgment, exact evidence, concise reason and ambiguity/refusal separately from formatting judgment. Producer item fields: span, claims, questions, uncertainty, status, refs; one per owned alias. Auditor item fields: finding, ref_ids, reasoning, severity, confidence. Use MATCH/DIVERGENCE/OMISSION/ADDITION for fidelity; refuse with items=[] and status=refused for insufficient evidence.

```json
{
  "role": "auditor",
  "production_contract": "semantic-task-v1",
  "source_spans": [
    {
      "alias": "s0",
      "text": "- CLM-A: vendor 47 recorded 35 pallets (REF-1001).\n- CLM-B: vendor 47 retained 40 pallets (REF-1002).\n- The date is absent. When was this recorded? The recorder is unnamed. Who recorded it? The interpretation remains uncertain."
    }
  ],
  "context_only_spans": [],
  "supplied_refs": [
    "REF-1001",
    "REF-1002"
  ],
  "required_refs": [
    "REF-1001",
    "REF-1002"
  ],
  "routed_rules": [],
  "extraction": "- CLM-A: vendor 47 recorded 35 pallets (REF-1001).\n- CLM-B: vendor 47 retained 40 pallets (REF-1002).\n- The date is absent. When was this recorded? The recorder is unnamed. Who recorded it? The interpretation remains uncertain."
}
```

## Response template (pending, not a submitted review)

```json
{
  "packet_id": "review-0e21ea030bdabda2aa6a2480",
  "input_sha256": "0e21ea030bdabda2aa6a24806c86b7b0e5b7d722402c0fbb1c5c7faf9aa4fe79",
  "review_version": "semantic-benchmark-v2",
  "reviewer_id": null,
  "reviewer_kind": null,
  "independence_attestation": false,
  "reviewed_at": null,
  "semantic_target": null,
  "semantic_judgment": null,
  "reason_components": [],
  "rationale": null,
  "ambiguity": null,
  "formatting_judgment": "not_assessed"
}
```
