# Independent semantic review

Packet: review-8426fbfa1f7b8afb4c793317

Review independently without consulting authored labels, split files, or transformation metadata. Return semantic judgment, exact evidence, concise reason and ambiguity/refusal separately from formatting judgment. Producer item fields: span, claims, questions, uncertainty, status, refs; one per owned alias. Auditor item fields: finding, ref_ids, reasoning, severity, confidence. Use MATCH/DIVERGENCE/OMISSION/ADDITION for fidelity; refuse with items=[] and status=refused for insufficient evidence.

```json
{
  "role": "auditor",
  "production_contract": "semantic-task-v1",
  "source_spans": [
    {
      "alias": "s0",
      "text": "1. Scope\n  1(a) CLM-A: survey plot 78 recorded 128 quadrats (REF-1001).\n  1(b) Exceptions\n    (i) CLM-B: survey plot 78 retained 133 quadrats (REF-1002).\n    (ii) The date is absent. When was this recorded?"
    }
  ],
  "context_only_spans": [],
  "supplied_refs": [
    "REF-1001",
    "REF-1002"
  ],
  "required_refs": [
    "REF-1001",
    "REF-1002"
  ],
  "routed_rules": [],
  "extraction": "1. Scope\n  1(a) CLM-A: survey plot 78 recorded 128 quadrats (REF-1001).\n  1(b) Exceptions\n    (i) CLM-B: survey plot 78 retained 133 quadrats (REF-1002).\n    (ii) The date is absent. When was this recorded?"
}
```

## Response template (pending, not a submitted review)

```json
{
  "packet_id": "review-8426fbfa1f7b8afb4c793317",
  "input_sha256": "8426fbfa1f7b8afb4c793317532a94dc2686f5702b27dc19c2a52d4e200266e5",
  "review_version": "semantic-benchmark-v2",
  "reviewer_id": null,
  "reviewer_kind": null,
  "independence_attestation": false,
  "reviewed_at": null,
  "semantic_target": null,
  "semantic_judgment": null,
  "reason_components": [],
  "rationale": null,
  "ambiguity": null,
  "formatting_judgment": "not_assessed"
}
```
