# Independent semantic review

Packet: review-ad9a66c3e2e277f8cd47a320

Review independently without consulting authored labels, split files, or transformation metadata. Return semantic judgment, exact evidence, concise reason and ambiguity/refusal separately from formatting judgment. Producer item fields: span, claims, questions, uncertainty, status, refs; one per owned alias. Auditor item fields: finding, ref_ids, reasoning, severity, confidence. Use MATCH/DIVERGENCE/OMISSION/ADDITION for fidelity; refuse with items=[] and status=refused for insufficient evidence.

```json
{
  "role": "auditor",
  "production_contract": "semantic-task-v1",
  "source_spans": [
    {
      "alias": "s0",
      "text": "| Field | Content |\n|---|---|\n"
    },
    {
      "alias": "s1e",
      "text": "| Primary | CLM-A: observing station 65 recorded 89 exposures (REF-1001). |\n"
    },
    {
      "alias": "s6a",
      "text": "| Secondary | No second claim was submitted. The date is absent. When was this recorded? The recorder is unnamed. Who recorded it? The interpretation remains uncertain. |"
    }
  ],
  "context_only_spans": [],
  "supplied_refs": [
    "REF-1001"
  ],
  "required_refs": [
    "REF-1001"
  ],
  "routed_rules": [],
  "extraction": "| Field | Content |\n|---|---|\n| Primary | CLM-A: observing station 65 recorded 90 exposures (REF-1001). |\n| Secondary | No second claim was submitted. The date is absent. When was this recorded? The recorder is unnamed. Who recorded it? The interpretation remains uncertain. |"
}
```

## Response template (pending, not a submitted review)

```json
{
  "packet_id": "review-ad9a66c3e2e277f8cd47a320",
  "input_sha256": "ad9a66c3e2e277f8cd47a320971d81064290613c8d68091dd6fb50da9f7a8d95",
  "review_version": "semantic-benchmark-v2",
  "reviewer_id": null,
  "reviewer_kind": null,
  "independence_attestation": false,
  "reviewed_at": null,
  "semantic_target": null,
  "semantic_judgment": null,
  "reason_components": [],
  "rationale": null,
  "ambiguity": null,
  "formatting_judgment": "not_assessed"
}
```
