# Independent semantic review

Packet: review-034cdcae3114a8fc5e88f9d5

Review independently without consulting authored labels, split files, or transformation metadata. Return semantic judgment, exact evidence, concise reason and ambiguity/refusal separately from formatting judgment. Producer item fields: span, claims, questions, uncertainty, status, refs; one per owned alias. Auditor item fields: finding, ref_ids, reasoning, severity, confidence. Use MATCH/DIVERGENCE/OMISSION/ADDITION for fidelity; refuse with items=[] and status=refused for insufficient evidence.

```json
{
  "role": "producer",
  "production_contract": "semantic-task-v1",
  "source_spans": [
    {
      "alias": "s0",
      "text": "BEGIN REGISTER\nDEBIT OBSERVATION :: CLM-C: service desk 83 is assigned 143 delivery windows (REF-1003).\nCREDIT OBSERVATION :: CLM-D: the same service desk 83 is assigned 145 delivery windows (REF-1004).\nMEMO ONLY :: These statements conflict. The effective time is missing. When does it take effect? The interpretation remains uncertain.\nEND REGISTER\n\n"
    }
  ],
  "context_only_spans": [
    {
      "alias": "s160",
      "text": "CONTEXT ONLY: CLM-Z: an unrelated neighbor lists a separate observation (REF-9999)."
    }
  ],
  "supplied_refs": [
    "REF-1003",
    "REF-1004",
    "REF-9999"
  ],
  "required_refs": [
    "REF-1003",
    "REF-1004"
  ],
  "routed_rules": []
}
```

## Response template (pending, not a submitted review)

```json
{
  "packet_id": "review-034cdcae3114a8fc5e88f9d5",
  "input_sha256": "034cdcae3114a8fc5e88f9d59b2b165bafbbc2d1740f4019d89b08ba3bac434e",
  "review_version": "semantic-benchmark-v2",
  "reviewer_id": null,
  "reviewer_kind": null,
  "independence_attestation": false,
  "reviewed_at": null,
  "semantic_target": null,
  "semantic_judgment": null,
  "reason_components": [],
  "rationale": null,
  "ambiguity": null,
  "formatting_judgment": "not_assessed"
}
```
