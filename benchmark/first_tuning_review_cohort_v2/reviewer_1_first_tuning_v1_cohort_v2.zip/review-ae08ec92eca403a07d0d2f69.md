# Independent semantic review

Packet: review-ae08ec92eca403a07d0d2f69

Review independently without consulting authored labels, split files, or transformation metadata. Return semantic judgment, exact evidence, concise reason and ambiguity/refusal separately from formatting judgment. Producer item fields: span, claims, questions, uncertainty, status, refs; one per owned alias. Auditor item fields: finding, ref_ids, reasoning, severity, confidence. Use MATCH/DIVERGENCE/OMISSION/ADDITION for fidelity; refuse with items=[] and status=refused for insufficient evidence.

```json
{
  "role": "auditor",
  "production_contract": "semantic-task-v1",
  "source_spans": [
    {
      "alias": "s0",
      "text": "Opening statement: CLM-A: observing station 73 recorded 113 exposures (REF-1001).\n\n| Supplement | Content |\n|---|---|\n"
    },
    {
      "alias": "s76",
      "text": "| Detail | No second claim was submitted. |"
    },
    {
      "alias": "sa1",
      "text": "\n\nClosing qualification: The date is absent. When was this recorded? The interpretation remains uncertain."
    }
  ],
  "context_only_spans": [],
  "supplied_refs": [
    "REF-1001"
  ],
  "required_refs": [
    "REF-1001"
  ],
  "routed_rules": [],
  "extraction": "Opening statement: CLM-A: observing station 73 recorded 113 exposures (REF-1001).\n\n| Supplement | Content |\n|---|---|\n| Detail | No second claim was submitted. |\n\nClosing qualification: The date is absent. When was this recorded? The interpretation remains uncertain."
}
```

## Response template (pending, not a submitted review)

```json
{
  "binding": {
    "revision": "first-tuning-review-cohort-v2",
    "cohort_sha256": "7006edd3f293ca2a6cdcebe071a05d05ac02c9bd58259d7c07110de4bd45bb8d",
    "payload_sha256": "5f64f06e23c69aaab87ed4f4f517471bf3d81387bb58f99c848d6077ecae37d6"
  },
  "review": {
    "packet_id": "review-ae08ec92eca403a07d0d2f69",
    "input_sha256": "ae08ec92eca403a07d0d2f69fb9645fb8a81c1fbe75b524de9cd76390c7adb5d",
    "review_version": "semantic-benchmark-v2",
    "reviewer_id": null,
    "reviewer_kind": null,
    "independence_attestation": false,
    "reviewed_at": null,
    "semantic_target": null,
    "semantic_judgment": null,
    "reason_components": [],
    "rationale": null,
    "ambiguity": null,
    "formatting_judgment": "not_assessed"
  }
}
```
