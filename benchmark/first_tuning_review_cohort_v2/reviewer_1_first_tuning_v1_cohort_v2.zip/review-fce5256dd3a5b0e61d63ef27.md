# Independent semantic review

Packet: review-fce5256dd3a5b0e61d63ef27

Review independently without consulting authored labels, split files, or transformation metadata. Return semantic judgment, exact evidence, concise reason and ambiguity/refusal separately from formatting judgment. Producer item fields: span, claims, questions, uncertainty, status, refs; one per owned alias. Auditor item fields: finding, ref_ids, reasoning, severity, confidence. Use MATCH/DIVERGENCE/OMISSION/ADDITION for fidelity; refuse with items=[] and status=refused for insufficient evidence.

```json
{
  "role": "auditor",
  "production_contract": "semantic-task-v1",
  "source_spans": [
    {
      "alias": "s0",
      "text": "| Sequence | Evidence |\n|---|---|\n"
    },
    {
      "alias": "s22",
      "text": "| 1 | CLM-A: survey plot 70 recorded 104 quadrats (REF-1001). |\n"
    },
    {
      "alias": "s62",
      "text": "| 2 | CLM-B: survey plot 70 retained 109 quadrats (REF-1002). |\n"
    },
    {
      "alias": "sa2",
      "text": "| 3 | The date is absent. When was this recorded? |"
    }
  ],
  "context_only_spans": [],
  "supplied_refs": [
    "REF-1001",
    "REF-1002"
  ],
  "required_refs": [
    "REF-1001",
    "REF-1002"
  ],
  "routed_rules": [],
  "extraction": "| Sequence | Evidence |\n|---|---|\n| 1 | CLM-A: survey plot 70 recorded 104 quadrats (REF-1001). |\n| 2 | CLM-B: survey plot 70 retained 109 quadrats (REF-1002). |\n| 3 | The date is absent. When was this recorded? |"
}
```

## Response template (pending, not a submitted review)

```json
{
  "binding": {
    "revision": "first-tuning-review-cohort-v2",
    "cohort_sha256": "7006edd3f293ca2a6cdcebe071a05d05ac02c9bd58259d7c07110de4bd45bb8d",
    "payload_sha256": "5f64f06e23c69aaab87ed4f4f517471bf3d81387bb58f99c848d6077ecae37d6"
  },
  "review": {
    "packet_id": "review-fce5256dd3a5b0e61d63ef27",
    "input_sha256": "fce5256dd3a5b0e61d63ef2755dafeea9b842e170a497289ae1c257c2f9efa54",
    "review_version": "semantic-benchmark-v2",
    "reviewer_id": null,
    "reviewer_kind": null,
    "independence_attestation": false,
    "reviewed_at": null,
    "semantic_target": null,
    "semantic_judgment": null,
    "reason_components": [],
    "rationale": null,
    "ambiguity": null,
    "formatting_judgment": "not_assessed"
  }
}
```
