"""Project Shimmer: authenticated single-worker HTTP front door.

Native console intake explicitly selects standalone mode, confirmation, privacy,
targets and prior files. Omitted intake mode keeps the legacy sidecar validator.
The worker stages input, runs pipeline.py as a subprocess and exposes saved run
resources. Native ownership-aware cleanup differs from legacy ingestion cleanup.

The desktop starter supplies a loopback server and ephemeral authentication.
Direct server setup, environment variables and the exact route table live in
docs/RUNTIME_REFERENCE.md; operator instructions live in docs/RUNBOOK.md. No token value belongs
in source, URLs or logs. /health and /console are public; data/action routes
require Bearer authentication. /health is liveness, not readiness or quality.

Approval writes a decision; the pipeline evaluates it. A successful process,
nonempty document folder or downloadable ZIP does not certify coverage or privacy.
See docs/fix/ROUTING_UI_AUDIT.md for the current artifact/consumer trace.
"""

# ---------------------------------------------------------------------------
# IMPORTS (what each one is for)
# ---------------------------------------------------------------------------
import hashlib      # turns the token into a fixed-length fingerprint (sha256).
import hmac         # hmac.compare_digest: compares two hashes in constant time.
import io           # an in-memory bytes buffer, used to build the results .zip.
import json         # reads the _corpus_ingest.json sidecar (the file manifest).
import os           # reads the SHIMMER_TOKEN_HASH environment variable.
import re           # validates a URL-supplied run_id against the mint format.
import shutil       # copies and removes files and directories.
import subprocess   # runs the validator and the pipeline as separate programs.
import sys          # sys.executable = the exact Python running this server.
import threading    # a Lock (to guard the queue) and a background run thread.
import time         # api STEP B2: bounded polling in POST /runs/{run_id}/cancel.
import zipfile      # packages the run's deliverables into one downloadable .zip.
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone   # timestamps for jobs and run ids.
from pathlib import Path                   # tidy, OS-independent file paths.
from typing import List, Optional          # 3.9-safe type hints for FastAPI.

# FastAPI is the web framework. uvicorn is the program that actually serves it.
# BackgroundTasks/Depends/Header/HTTPException/UploadFile/File are FastAPI helpers
# explained at their first use below.
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
import uvicorn

# ---------------------------------------------------------------------------
# PATHS (everything is anchored to the repo root, computed from THIS file)
# ---------------------------------------------------------------------------
# This file lives at <repo>/scripts/server.py, so the repo root is two levels up.
ROOT = Path(__file__).resolve().parent.parent

# productization STEP 10: make the sibling modules under scripts/ importable no
# matter HOW this file is loaded. `python scripts/server.py` puts scripts/ on
# sys.path automatically, but an external ASGI runner (`uvicorn scripts.server:app`
# from the repo root, the shape any container or process manager would use) puts
# only the repo root there, so the bare `import role_resolution` in
# _clear_system_draft raised ModuleNotFoundError the first time a draft job
# finished. Idempotent, and a no-op on the direct-launch path.
_SCRIPTS_DIR = str(Path(__file__).resolve().parent)
if _SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, _SCRIPTS_DIR)
CONTEXT_DIR = ROOT / "input" / "context"          # where grounding files live.
PIPELINE = ROOT / "scripts" / "pipeline.py"       # the review pipeline (subprocess).
VALIDATOR = ROOT / "corpus_ingest" / "validate_contract.py"  # the contract validator.
SIDECAR_NAME = "_corpus_ingest.json"              # the manifest the collaborator uploads.
UI_CONSOLE_PATH = ROOT / "scripts" / "ui" / "console.html"  # STEP 6: the operator console.

# The environment variable that holds the SHA-256 hash of the collaborator's token.
TOKEN_HASH_ENV = "SHIMMER_TOKEN_HASH"

# ---------------------------------------------------------------------------
# CONFIG (read ONCE from the environment at startup; see the docstring reference)
# ---------------------------------------------------------------------------
# Every value falls back to a sensible default when its variable is unset, so the
# server runs out of the box. The resolved set is printed to stderr on launch.
def _env_bool(name: str, default: bool) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in {"1", "true", "yes", "y", "on"}


def _env_int(name: str, default: int) -> int:
    v = os.environ.get(name)
    if v is None or not v.strip():
        return default
    try:
        return int(v.strip())
    except ValueError:
        return default


MODE = os.environ.get("SHIMMER_MODE", "integrated")        # standalone | integrated
TASK_DEFAULT = os.environ.get("SHIMMER_TASK", "review")    # review | draft (per /submit)
SENSITIVE = _env_bool("SHIMMER_SENSITIVE", False)          # redaction on/off for the run
MAX_DOCS = _env_int("SHIMMER_MAX_DOCS", 4)                 # --max-concurrent-docs
from startup_settings import server_endpoint
HOST, PORT, CONSOLE_URL = server_endpoint()
AUTO_CLEAR = _env_bool("SHIMMER_AUTO_CLEAR", True)         # clear ingested files after a run
LOG_LEVEL = os.environ.get("SHIMMER_LOG_LEVEL", "info")    # uvicorn log level
# Per-run output root: a custom SHIMMER_OUTPUT_DIR, else the default output/runs/.
RUNS_DIR = Path(os.environ.get("SHIMMER_OUTPUT_DIR") or (ROOT / "output" / "runs"))
# productization STEP 3: timeouts and upload limits, all read once at startup.
RUN_TIMEOUT_S = _env_int("SHIMMER_RUN_TIMEOUT_S", 0)        # 0 = unbounded (prior behavior)
LOCAL_RUN_TIMEOUT_S = _env_int("SHIMMER_LOCAL_RUN_TIMEOUT_S", 7200)  # 2 hours for local mode

# api STEP A1: the two review modes the pipeline offers (--review-mode), named
# here so /submit can validate the field without importing pipeline.py.
REVIEW_MODES = ("paired", "wide")


def _backend_profile() -> str:
    """The resolved backend profile, "local" or "cloud".

    Read live from the environment (not frozen at import) because
    _effective_run_timeout and check_local_model_availability already read
    SHIMMER_BACKEND_PROFILE live, and a second, import-time copy of the same
    knob would be a way for the two to disagree. Anything that is not exactly
    "local" is the cloud profile, matching those two readers.
    """
    from run_choices import resolve_backend_profile
    return resolve_backend_profile(os.environ.get("SHIMMER_BACKEND_PROFILE"), legacy_default=True)


def _default_review_mode() -> str:
    """The review mode a submission gets when the caller names none: paired under
    the local profile, wide under cloud.

    This MIRRORS pipeline.resolve_review_mode(None, backend_profile) rather than
    importing it: pipeline.py is a large module and /health must not pay to
    import it. The mirror is pinned to the original by a gate check, so the two
    cannot drift apart silently.
    """
    return "paired" if _backend_profile() == "local" else "wide"


def _effective_run_timeout() -> int:
    """Return the active run timeout: LOCAL_RUN_TIMEOUT_S when the backend profile
    is 'local', otherwise RUN_TIMEOUT_S. Both support 0 = unbounded."""
    if os.environ.get("SHIMMER_BACKEND_PROFILE") == "local":
        return LOCAL_RUN_TIMEOUT_S
    return RUN_TIMEOUT_S


def check_local_model_availability():
    """When SHIMMER_BACKEND_PROFILE=local, verify that the required packages
    (torch, transformers) are importable and that both model IDs resolve to
    a local cache entry. Returns (ok: bool, detail: str)."""
    from preflight import check_local_model_availability as check
    return check()


MAX_UPLOAD_MB = _env_int("SHIMMER_MAX_UPLOAD_MB", 25)       # per-file cap
MAX_UPLOAD_TOTAL_MB = _env_int("SHIMMER_MAX_UPLOAD_TOTAL_MB", 200)  # whole-submission cap
MAX_UPLOAD_FILES = _env_int("SHIMMER_MAX_UPLOAD_FILES", 50) # file-count cap per submission

# New runs share the CLI's UUID format; old timestamped URLs remain valid.
# Every run route validates this bounded syntax before constructing a path.
from run_context import SERVER_RUN_ID_RE as _RUN_ID_RE

# productization STEP 6: exit-code -> status mapping. Replaces the old blanket
# "any non-zero exit is failed" collapse. "blocked" and the three "stopped_*"
# entries are governance outcomes (the pipeline refused or paused ON PURPOSE),
# never rendered as errors by the console. Exit 5 is deliberately overloaded
# upstream (pipeline.py: a redaction BLOCK at run-end, OR a draft-mode phase-0
# generation failure); this map cannot distinguish the two by exit code alone,
# so the console note tells the operator to check the log tail (see /runs and
# the run detail's logs_path). Sourced from pipeline.py's own `return N` exit
# points: 0 success (or 5 if a redaction BLOCK), 2 snapshot conflict
# (--save-snapshot only), 3 model-gate stop, 4 redaction-gate stop, 5 blocked
# (dual meaning, see above), 6 sensitivity-layer-inactive refusal, 7 operator
# abort (meta-signature decline). Anything else non-zero is a plain failure.
_EXIT_STATUS_MAP = {
    0: "completed",
    2: "snapshot_conflict",
    3: "stopped_model_approval",
    4: "stopped_redaction_gate",
    5: "blocked",
    6: "refused_sensitivity_layer_inactive",
    7: "operator_abort",
}
# Exit codes whose status is a governance outcome, not a failure: the console
# must render these distinctly from a crash (item 4 of STEP 6).
GOVERNANCE_STATUSES = {"blocked", "stopped_model_approval", "stopped_redaction_gate",
                       "refused_sensitivity_layer_inactive"}


def _status_for_exit_code(exit_code):
    """Map a raw pipeline exit code to its distinct status string. None (a run
    timeout, exit_code never observed) is handled by the caller before this is
    reached; here exit_code is always an int. Any code not in the table above,
    zero or non-zero, that is not otherwise a known governance/success code is
    "failed"."""
    if exit_code == 0:
        return "completed"
    return _EXIT_STATUS_MAP.get(exit_code, "failed")


def _config_summary() -> str:
    """The resolved config as one stderr line (the operator's at-a-glance check)."""
    return (f"[server] mode={MODE}, task={TASK_DEFAULT}, sensitive={str(SENSITIVE).lower()}, "
            f"max_docs={MAX_DOCS}, port={PORT}, host={HOST}, "
            f"auto_clear={str(AUTO_CLEAR).lower()}, output_dir={RUNS_DIR}, "
            f"log_level={LOG_LEVEL}, run_timeout_s={_effective_run_timeout()}, "
            f"max_upload_mb={MAX_UPLOAD_MB}, max_upload_total_mb={MAX_UPLOAD_TOTAL_MB}, "
            f"max_upload_files={MAX_UPLOAD_FILES}")

# ---------------------------------------------------------------------------
# THE APP
# ---------------------------------------------------------------------------
# FastAPI() builds the web application object. Routes (the URLs the server answers)
# are attached to it with decorators like @app.post("/submit") below.
@asynccontextmanager
async def _lifespan(app):
    _STOPPING.clear()
    try:
        yield
    finally:
        if not shutdown_jobs():
            raise RuntimeError("Shimmer could not stop every review worker; inspect the server log.")


app = FastAPI(title="Project Shimmer front door", version="1.0", lifespan=_lifespan)


# ---------------------------------------------------------------------------
# TOKEN AUTH (the gate)
# ---------------------------------------------------------------------------
# This is the gate. Anyone with the URL but not the token gets rejected here. We
# store only the token's sha256 HASH (in an environment variable), never the token
# itself, so even someone who reads the server's environment cannot recover it.
def _check_token(authorization):
    """The core token check. `authorization` is the raw value of the request's
    Authorization header (the string "Bearer <token>"), or None if absent.

    Raises HTTPException(401) if: the server has no token hash configured, the
    header is missing or malformed, or the token does not match. Returns None on a
    correct token. Kept as a plain function (not tied to FastAPI internals) so the
    verify gate can call it directly to prove 401 behavior."""
    stored_hash = os.environ.get(TOKEN_HASH_ENV)
    if not stored_hash:
        # No hash configured: the server cannot authenticate anyone, so refuse all.
        raise HTTPException(status_code=401, detail="server has no token configured")
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="missing or malformed Authorization header")
    token = authorization[len("Bearer "):].strip()
    # Hash what the caller sent, then compare to the stored hash. compare_digest is
    # used instead of == so the comparison time does not leak how many characters matched.
    sent_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
    if not hmac.compare_digest(sent_hash, stored_hash):
        raise HTTPException(status_code=401, detail="invalid token")
    return None


# A FastAPI "dependency": FastAPI runs this before a protected route. Header(...)
# tells FastAPI to pull the Authorization header out of the request for us. If
# _check_token raises, FastAPI turns it into the 401 response automatically.
async def verify_token(authorization: Optional[str] = Header(default=None)):
    _check_token(authorization)


# ---------------------------------------------------------------------------
# THE QUEUE (a Python list in memory, mirrored to disk per run)
# ---------------------------------------------------------------------------
# The queue is a list of "job" dictionaries. Each job records its run id, current
# status, timestamps, an error message if it failed, and the filenames submitted.
# JOBS is the source of truth for the LIVE process.
#
# productization STEP 2 added a disk mirror, so a restart no longer loses the
# queue (this comment used to say "No database, no files, no persistence", which
# stopped being true in the same file). There is still no database and no queue
# file: every job's record is written to its OWN run folder as
# <run>/status.json by _write_status on each status transition, and
# _rebuild_jobs_from_disk() reads those files back at import to repopulate JOBS.
# A run that was "running" when the process died is rewritten as "interrupted"
# rather than being reported as still in flight, and an orphaned staging dir for
# a job that is no longer running is removed. Gate checks 88 to 91 cover exactly
# that path.
JOBS = []                      # the public job records (returned by /runs, /runs/{run_id}).
JOBS_LOCK = threading.Lock()   # guards JOBS: HTTP requests arrive on many threads.
_STAGING = {}                  # private: run_id -> staging dir holding validated uploads.
                                # (productization STEP 2: guarded by JOBS_LOCK like JOBS)

# api STEP B2 (cancellation): before this step, the live subprocess.Popen
# object for a running job existed ONLY as a local variable inside _run_job,
# reachable solely by the run-timeout Timer's own closure (see the comment
# above that Timer below) -- nothing outside that one function could reach
# it, so nothing outside could ever ask it to stop. _PROCS is that missing
# place: run_id -> Popen, registered the moment Popen succeeds, removed in
# _run_job's own `finally` (terminal or not, so a run that crashes before
# reaching its own cleanup never leaves a stale entry). Guarded by the SAME
# JOBS_LOCK the rest of the job bookkeeping already uses, not a second lock,
# so a caller that holds JOBS_LOCK can always safely look here too.
_PROCS = {}
# run_id -> threading.Event, set by POST /runs/{run_id}/cancel the instant a
# RUNNING job is asked to stop. _run_job's post-subprocess bookkeeping checks
# this (alongside the existing `timed_out` Event from the run-timeout path)
# to tell "the caller cancelled this" apart from "the child process crashed
# or exited non-zero on its own" -- both end with the same subprocess exit
# mechanics (terminate/kill), so the DISTINCTION has to be recorded
# separately, not inferred from the exit code. Removed alongside _PROCS.
_CANCELLED = {}
_THREADS = {}
_STOPPING = threading.Event()


def _now_iso():
    """Current UTC time as an ISO-8601 string, for the job timestamps."""
    return datetime.now(timezone.utc).isoformat()


def _new_run_id():
    """Use the same immutable identifier as every other run entry point."""
    from run_context import new_run_id
    return new_run_id()


def _find_job(run_id):
    """Return the job dict for a run id, or None. Caller holds JOBS_LOCK."""
    return next((j for j in JOBS if j["run_id"] == run_id), None)


# ---------------------------------------------------------------------------
# STEP 2: run state on disk (productization). The JOBS list above is now a
# read-through CACHE over a per-run status.json; the file is the durable
# record, JOBS is what /runs and /runs/{run_id} answer from without touching
# disk on every request. A job dict, plus "exit_code", is what gets written.
# ---------------------------------------------------------------------------
_STATUS_FIELDS = ("run_id", "status", "task", "submitted_at", "started_at",
                   "completed_at", "exit_code", "error", "progress", "files",
                   "sensitive", "review_mode", "question", "intake_mode",
                   "review_targets", "prior_files", "native_intake",
                   "input_language", "output_language", "agent_briefs")


def _status_path(run_id):
    # Delegates to run_context.RunContext.status_path() (the single source of
    # truth for this path shape) rather than reimplementing it, so the server
    # and any future pipeline-side writer of status.json can never drift.
    import run_context as _rc
    return _rc.for_run_dir(ROOT, RUNS_DIR / run_id).status_path()


def _write_status(job):
    """Atomically write this job's status.json (temp file then replace, as
    cost_tracker.py::_persist_snapshot does). Best-effort: a write failure
    (e.g. the run folder not created yet) never raises into the caller, since
    JOBS (in-memory) remains the source of truth for the live process."""
    try:
        path = _status_path(job["run_id"])
        path.parent.mkdir(parents=True, exist_ok=True)
        record = {k: job.get(k) for k in _STATUS_FIELDS}
        if job.get("multi_round") is True:
            record["multi_round"] = True
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(record, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)
    except OSError:
        pass


def _rebuild_jobs_from_disk():
    """Scan RUNS_DIR for status.json files and rebuild JOBS from them (called once
    at import). Running jobs have no owned process and queued jobs have no
    restored staging map after restart. Both become terminal "interrupted"
    records that require resubmission, in memory and in status.json.
    Also removes orphaned staging dirs (the ingest_<run_id>_ prefix in
    the system temp dir) for any run that is not running, and applies the existing
    _auto_clear / _clear_system_draft cleanup for whatever an interrupted run left
    behind in input/context/."""
    import tempfile as _tempfile

    jobs = []
    interrupted_any = False
    if RUNS_DIR.is_dir():
        for run_dir in sorted(RUNS_DIR.iterdir()):
            if not run_dir.is_dir():
                continue
            sp = run_dir / "status.json"
            if not sp.exists():
                continue
            try:
                record = json.loads(sp.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            job = {k: record.get(k) for k in _STATUS_FIELDS}
            if record.get("multi_round") is True:
                job["multi_round"] = True
            job.setdefault("run_id", run_dir.name)
            if job.get("status") == "running":
                job["status"] = "interrupted"
                job["error"] = job.get("error") or "server restarted while this run was in progress"
                job["completed_at"] = job.get("completed_at") or _now_iso()
                _write_status(job)
                interrupted_any = True
            elif job.get("status") == "queued":
                job["status"] = "interrupted"
                job["error"] = "server restarted before this review began; submit the plan and its files again"
                job["completed_at"] = _now_iso()
                _write_status(job)
            jobs.append(job)

    # UUIDs are opaque. Queue order belongs to submitted_at, not folder spelling.
    jobs.sort(key=lambda job: (job.get("submitted_at") or "", job.get("run_id") or ""))
    with JOBS_LOCK:
        JOBS.clear()
        JOBS.extend(jobs)
        running_ids = {j["run_id"] for j in JOBS if j["status"] == "running"}

    # Orphaned staging dirs: any ingest_<run_id>_* temp dir whose run is not
    # currently running. Recovered queued jobs are now terminal too: uploads
    # cannot be safely attached to a fresh process without a restored staging map.
    # Unknown staging directories remain untouched.
    tmp_root = Path(_tempfile.gettempdir())
    try:
        entries = list(tmp_root.iterdir())
    except OSError:
        entries = []
    known_run_ids = {j["run_id"] for j in jobs}
    for p in entries:
        if not p.is_dir() or not p.name.startswith("ingest_"):
            continue
        # ingest_<run_id>_<random>: run_id itself contains "__", so split on the
        # trailing "_<random>" suffix mkdtemp appended is unsafe; instead check
        # membership by prefix against every known non-running run_id.
        rid = next((r for r in known_run_ids if p.name.startswith(f"ingest_{r}_")), None)
        if rid is not None and rid in running_ids:
            continue  # a genuinely running job's staging dir (not possible at
                       # fresh import, kept for safety if this is ever re-run).
        if rid is None:
            continue  # not a recognizable job staging dir; leave it alone.
        shutil.rmtree(p, ignore_errors=True)

    if interrupted_any:
        _auto_clear()
        _clear_system_draft()


def _progress_string(line):
    """Return the `key=value ...` body of a pipeline `[progress]` line, or None for any
    other line. Stored on the job and returned by GET /runs/{run_id}."""
    s = line.strip()
    if s.startswith("[progress]"):
        return s[len("[progress]"):].strip()
    return None


def _start_next_job():
    """Start the next queued job IF nothing is currently running. Called after every
    submission and after every run finishes, so the queue drains one job at a time.

    Picking the job and flipping it to 'running' happens under the lock; the actual
    work runs in a separate background thread so the HTTP request that triggered this
    returns immediately."""
    with JOBS_LOCK:
        if _STOPPING.is_set():
            return
        if any(j["status"] == "running" for j in JOBS):
            return  # one at a time: a job is already running, leave the rest queued.
        nxt = next((j for j in JOBS if j["status"] == "queued"), None)
        if nxt is None:
            return  # nothing waiting.
        nxt["status"] = "running"
        nxt["started_at"] = _now_iso()
        run_id = nxt["run_id"]
        _write_status(nxt)
        def work():
            try:
                _run_job(run_id)
            finally:
                with JOBS_LOCK:
                    _THREADS.pop(run_id, None)
        worker = threading.Thread(target=work, daemon=True)
        _THREADS[run_id] = worker
        worker.start()


def _stop_process(proc, timeout_s=10):
    """Wait for an owned child, escalating a bounded graceful stop to kill."""
    if proc.poll() is None:
        proc.terminate()
    try:
        proc.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=timeout_s)


def shutdown_jobs(timeout_s=10):
    """Stop accepting work, cancel owned jobs, stop children and join workers.

    The desktop server wrapper calls this on Stop/EOF as well as the ASGI
    lifespan. False means cleanup did not finish, never successful shutdown.
    """
    _STOPPING.set()
    with JOBS_LOCK:
        for event in _CANCELLED.values():
            event.set()
        queued_staging = []
        for job in JOBS:
            if job.get("status") == "queued":
                job.update(status="cancelled", error="server stopped before this review started",
                           completed_at=_now_iso())
                _write_status(job)
                staged = _STAGING.pop(job["run_id"], None)
                if staged:
                    queued_staging.append(staged)
        processes = list(_PROCS.values())
        workers = list(_THREADS.values())
    ok = True
    for proc in processes:
        try:
            _stop_process(proc, timeout_s)
        except (OSError, subprocess.TimeoutExpired):
            ok = False
    for worker in workers:
        if worker is not threading.current_thread():
            worker.join(timeout_s)
            ok = not worker.is_alive() and ok
    for staged in queued_staging:
        shutil.rmtree(staged, ignore_errors=True)
    return ok


def _upload_name(value):
    """Reject ambiguous filenames on either platform before constructing a path."""
    name = str(value or "")
    if (not name or name in {".", ".."} or name[-1:] in {".", " "}
            or any(ch in name for ch in '/\\:<>"|?*')
            or any(ord(ch) < 32 for ch in name)
            or re.fullmatch(r"(?i)(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?", name)):
        raise HTTPException(400, "A filename is not safe to import. Rename the file and select it again.")
    return name


def _filename_list(value, field):
    try:
        names = json.loads(value or "[]")
        if not isinstance(names, list) or any(not isinstance(n, str) for n in names):
            raise ValueError()
        names = [_upload_name(n) for n in names]
        if len({n.casefold() for n in names}) != len(names):
            raise ValueError()
        return names
    except (ValueError, TypeError):
        raise HTTPException(400, f"{field} must list distinct selected filenames.")


def _standalone_plan(staging, task, targets, prior):
    """Validate native intake with the existing classifier and document parser.

    This only reads staged uploads and operator state. A reviewed document,
    grounding file or prior is an explicit operator choice, never a fabricated
    external-ingestion sidecar. Config and metadata uploads are refused.
    """
    import intake_wizard
    import role_resolution
    import text_extract
    entries, documents, conventions = [], [], []
    for path in sorted(Path(staging).iterdir()):
        kind, _, relative = intake_wizard.classify(path)
        if kind not in {"DOCUMENT", "CONVENTIONS"} or path.name.startswith("_"):
            raise HTTPException(400, f"{path.name}: choose a document or a review rules file. Settings and metadata cannot be uploaded here.")
        if kind == "DOCUMENT":
            if not text_extract.extract_text(path).strip():
                raise HTTPException(400, f"{path.name}: no readable document text was found. Check the file or export it as text.")
            documents.append(path.name)
        else:
            conventions.append(path)
        destination = ROOT / relative / path.name
        # Test harnesses and custom context roots must use the same authority.
        if kind == "DOCUMENT":
            destination = CONTEXT_DIR / path.name
        if destination.exists() and (not destination.is_file() or destination.read_bytes() != path.read_bytes()):
            raise HTTPException(409, f"{path.name} already exists with different content. Rename the uploaded file or resolve the existing file first.")
        entries.append((path, destination))
    summary = intake_wizard.summarize_conventions(conventions)
    if summary["unreadable"]:
        raise HTTPException(400, "A review rules file could not be read. Save it as UTF-8 text and select it again.")
    if (not set(targets) <= set(documents) or not set(prior) <= set(documents)
            or set(targets) & set(prior)):
        raise HTTPException(400, "Choose review targets and earlier versions from the uploaded documents, with a different role for each file.")
    if task == "review" and not targets:
        raise HTTPException(400, "Select at least one uploaded document to review.")
    if task == "draft" and (targets or prior):
        raise HTTPException(400, "Drafting uses uploaded documents as grounding. Choose Review to compare an earlier version.")
    existing_documents = {p.name for p in CONTEXT_DIR.iterdir()
                          if p.is_file() and text_extract.is_corpus_file(p)} if CONTEXT_DIR.is_dir() else set()
    grounding = sorted((set(documents) | existing_documents) - set(targets))
    manifest = role_resolution.read_manifest(CONTEXT_DIR)
    manifest_file = role_resolution.manifest_path(CONTEXT_DIR)
    if manifest_file.exists():
        if (task == "draft" or manifest is None
                or role_resolution.manifest_targets(manifest) != set(targets)
                or role_resolution.manifest_prior(manifest) != set(prior)
                or not set(grounding) <= role_resolution.manifest_grounding(manifest)):
            raise HTTPException(409, "Existing review instructions conflict with this plan. Resolve the current document selection before submitting; it has been preserved.")
    return entries, grounding


def _place_standalone(staging, task, targets, prior, created):
    import role_resolution
    entries, grounding = _standalone_plan(staging, task, targets, prior)
    for source, destination in entries:
        destination.parent.mkdir(parents=True, exist_ok=True)
        if not destination.exists():
            data = source.read_bytes()
            with destination.open("xb") as handle:
                handle.write(data)
            created.append((destination, hashlib.sha256(data).digest()))
    if not role_resolution.manifest_path(CONTEXT_DIR).exists():
        # Draft phase 0 replaces the temporary draft target list with its memo,
        # retaining this explicit grounding through the canonical role reader.
        path = role_resolution.write_manifest(CONTEXT_DIR, targets if task == "review" else [],
                                              "operator" if task == "review" else "system_draft",
                                              grounding=grounding, prior=prior, now_iso=_now_iso())
        created.append((path, hashlib.sha256(path.read_bytes()).digest()))


def _clear_standalone(created):
    """Remove only unchanged files this submission created, never operator edits."""
    for path, fingerprint in reversed(created):
        try:
            if path.is_file() and hashlib.sha256(path.read_bytes()).digest() == fingerprint:
                path.unlink()
        except OSError:
            pass


def _auto_clear():
    """Remove the ingested files placed in input/context/ for the run that just
    finished.

    Auto-clear prevents stale ingested cases from leaking into the next run. The sidecar
    is the manifest: ONLY files it names are removed, plus the sidecar itself. The
    operator's own context files (anything not listed in the sidecar) are never
    touched. A missing or unreadable sidecar means nothing to clear."""
    sidecar = CONTEXT_DIR / SIDECAR_NAME
    try:
        data = json.loads(sidecar.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return
    for entry in data.get("cases", []):
        if isinstance(entry, dict):
            fname = entry.get("file")
            if isinstance(fname, str) and fname:
                # Use only the basename, so a crafted "file" can never point outside
                # input/context/ (defense against path traversal).
                target = CONTEXT_DIR / Path(fname).name
                try:
                    target.unlink()
                except OSError:
                    pass  # already gone or not a file: nothing to do.
    try:
        sidecar.unlink()
    except OSError:
        pass


def _clear_system_draft():
    """Remove a SYSTEM-generated draft memo and its manifest so a draft job's artifacts
    do not leak into the next job (the server is stateless per job). Delegates to the
    canonical role_resolution.clear_system_draft so the rule lives in one place."""
    import role_resolution
    role_resolution.clear_system_draft(CONTEXT_DIR)


def _run_job(run_id):
    """The background worker for one job. Runs on its own thread (see
    _start_next_job). Steps: place this job's validated files into input/context/,
    run the pipeline as a subprocess writing to output/runs/<run_id>/, record the
    outcome, auto-clear, then start the next queued job.

    api STEP B2: registers the subprocess in _PROCS the moment it starts (so a
    concurrent POST /runs/{run_id}/cancel can find and terminate it) and
    checks _CANCELLED after the subprocess exits, to record "cancelled" as
    its own status rather than folding a deliberate stop into "failed"."""
    out_dir = RUNS_DIR / run_id
    error = None
    exit_code = None
    proc = None
    created = []
    cancel_event = threading.Event()
    with JOBS_LOCK:
        _CANCELLED[run_id] = cancel_event
        job = _find_job(run_id)
        task = (job or {}).get("task") or "review"
        question = (job or {}).get("question") or ""
        intake_mode = (job or {}).get("intake_mode") or MODE
        native_intake = bool((job or {}).get("native_intake"))
        targets = (job or {}).get("review_targets") or []
        prior = (job or {}).get("prior_files") or []
        job_sensitive = (job or {}).get("sensitive")
        if job_sensitive is None:
            job_sensitive = SENSITIVE
        # api STEP A1: resolved at submit time and stored on the job, so a job
        # queued under one profile keeps the mode it was accepted with even if
        # the environment changes before the worker picks it up.
        job_review_mode = (job or {}).get("review_mode") or _default_review_mode()
    try:
        out_dir.mkdir(parents=True, exist_ok=True)

        # Place this job's files into input/context/ at RUN START (not at submit
        # time), so that while one job runs, a second queued job's files are not
        # sitting in input/context/ corrupting the first. The files were validated
        # and staged at submit time; here we just copy them in.
        with JOBS_LOCK:
            staging = _STAGING.get(run_id)
        if _STOPPING.is_set():
            cancel_event.set()
            raise RuntimeError("server stopped before this review started")
        if native_intake:
            if not staging or not Path(staging).is_dir():
                raise RuntimeError("The uploaded files are unavailable. Submit the plan and its files again; no review was started.")
            _place_standalone(staging, task, targets, prior, created)
        elif staging and Path(staging).is_dir():
            for p in sorted(Path(staging).iterdir()):
                if p.is_file():
                    shutil.copy2(p, CONTEXT_DIR / p.name)

        # Run the existing pipeline as a SEPARATE program. We use sys.executable (the
        # same Python running this server). The flags come from the resolved CONFIG:
        #   --output-dir   : pin the run folder so we know exactly where results land.
        #   --mode MODE    : SHIMMER_MODE (default integrated). integrated activates the
        #       M1 promotion exclusion (grounding cases stay out of the operational review).
        #   --max-concurrent-docs MAX_DOCS : SHIMMER_MAX_DOCS (default 4). 4 is safe for a
        #       single-key Claude rate limit; raise it if your limits allow.
        #   --task TASK    : this job's task (review default, or draft). For draft we also
        #       pass --question; phase 0 generates a memo and reviews it.
        #   --review-mode MODE : this job's review mode (api STEP A1). Always passed
        #       explicitly, never left to the pipeline's own default, so the mode the
        #       caller was told they got (in the /submit response and in status.json)
        #       is provably the mode the child ran.
        #   --non-interactive --skip-confirmation : never wait for a human at the prompt.
        # When the run is NOT sensitive (SHIMMER_SENSITIVE=false, the default) we also pass:
        #   --sensitivity-layer-inactive-override : the full LAW-IV outbound masking layer
        #       ships built but INACTIVE (INFRA-038); the pipeline hard-stops rather than
        #       start silently with it off, so we declare the run non-sensitive (logged to
        #       the governance ledger).
        #   --no-redaction-override : declare the run redact-nothing (no Stage-3a scrub).
        # A sensitive run (SHIMMER_SENSITIVE=true) passes NEITHER override, so redaction
        # runs; that path requires the operator to have activated the LAW-IV layer.
        argv = [sys.executable, "-X", "utf8", str(PIPELINE),
                "--output-dir", str(out_dir),
                "--mode", intake_mode,
                "--task", task,
                "--max-concurrent-docs", str(MAX_DOCS),
                "--non-interactive", "--skip-confirmation",
                # productization STEP 6: file-backed operator channel. A governed
                # decision (model-gate stop, constitution amendment) that would
                # otherwise deny/stop unconditionally under --non-interactive now
                # parks as <run>/audit/pending_approval.json and waits for a human
                # to answer via POST /runs/{run_id}/approval (see GET /approvals).
                "--operator-channel", "file",
                "--review-mode", job_review_mode]
        import run_options
        language = run_options.normalize((job or {}).get("input_language"), (job or {}).get("output_language"), (job or {}).get("agent_briefs"))
        argv += ["--input-language", language.input_language, "--output-language", language.output_language,
                 "--agent-briefs", language.agent_briefs]
        if (job or {}).get("multi_round") is True:
            argv += ["--multi-round", "--multi-round-manifest",
                     str(out_dir / "audit" / "multi_round_request.json")]
        if question:
            # R6: a review run may carry an optional framing question too (folded
            # into every agent's run objectives and echoed in the deliverables);
            # draft still requires one (validated in submit).
            argv += ["--question", question]
        _bp = os.environ.get("SHIMMER_BACKEND_PROFILE")
        if _bp:
            argv += ["--backend-profile", _bp]
        from run_choices import privacy_flags
        argv += privacy_flags(bool(job_sensitive))
        # Stream the merged output so the latest [progress] line can be stored on the job
        # (returned by GET /runs/{run_id}) while the run is in flight. We keep a bounded tail for
        # the failure message, AND (productization STEP 6 item 5) write the complete
        # merged stream to <run>/logs/pipeline_stdout.log as it arrives, so the operator
        # can inspect the full run, not just a 2000-character tail.
        # api STEP B2: the moment the child exists, register its handle where a
        # concurrent HTTP request can find it. Guarded by JOBS_LOCK, matching
        # every other write to run-scoped shared state in this function.
        with JOBS_LOCK:
            if _STOPPING.is_set():
                cancel_event.set()
                raise RuntimeError("server stopped before this review started")
            proc = subprocess.Popen(
                argv, cwd=str(ROOT), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace", bufsize=1,
            )
            _PROCS[run_id] = proc
        log_dir = out_dir / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / "pipeline_stdout.log"
        # productization STEP 3: run timeout. The `for line in proc.stdout` loop
        # below blocks until the child closes stdout (i.e. exits), so a plain
        # proc.wait(timeout=...) placed AFTER that loop would never fire on a
        # genuinely hung child. Instead, a daemon Timer fires termination (then
        # kill) if the run outlives RUN_TIMEOUT_S; this unblocks the read loop
        # by closing the child's stdout, so the loop below exits either way and
        # timed_out is checked afterward to decide the outcome. RUN_TIMEOUT_S=0
        # (default) means no Timer is armed at all: unbounded, prior behavior.
        timed_out = threading.Event()
        timer = None
        eff_timeout = _effective_run_timeout()
        if eff_timeout > 0:
            def _on_timeout():
                timed_out.set()
                proc.terminate()
                try:
                    proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    proc.kill()
            timer = threading.Timer(eff_timeout, _on_timeout)
            timer.daemon = True
            timer.start()
        try:
            tail = []
            # productization STEP 6 item 5: the full merged stream is appended to
            # <run>/logs/pipeline_stdout.log line by line as it arrives (never
            # buffered fully in memory the way `tail` deliberately is), so a run
            # detail view can link the complete log regardless of outcome.
            with open(log_path, "a", encoding="utf-8", errors="replace") as logf:
                for line in proc.stdout:
                    tail.append(line)
                    if len(tail) > 300:
                        del tail[:100]
                    logf.write(line)
                    logf.flush()
                    prog = _progress_string(line)
                    if prog is not None:
                        with JOBS_LOCK:
                            j = _find_job(run_id)
                            if j is not None:
                                j["progress"] = prog
                                _write_status(j)
            proc.wait()
        finally:
            if timer is not None:
                timer.cancel()
            # api STEP B2: _PROCS' entry is only ever valid while this function
            # is between spawning proc and recording its outcome; remove it as
            # soon as the subprocess has exited (terminal or not) so a cancel
            # request arriving after this point correctly finds nothing to
            # terminate, rather than a handle to an already-dead process.
            with JOBS_LOCK:
                _PROCS.pop(run_id, None)
        if cancel_event.is_set():
            # api STEP B2: a caller asked this run to stop. The subprocess was
            # already terminated/killed by the cancel route (the same
            # sequence _on_timeout uses below); this is a DELIBERATE stop, not
            # a timeout and not an organic non-zero exit, so it must not be
            # reported as either. exit_code is recorded for reference but is
            # not what decides the status below (see the outcome block).
            error = "cancelled by request"
            exit_code = proc.returncode
        elif timed_out.is_set():
            error = f"run timeout after {eff_timeout}s"
            exit_code = None
        else:
            exit_code = proc.returncode
            if proc.returncode != 0:
                error = f"pipeline exited {proc.returncode}: {''.join(tail).strip()[-2000:]}"
    except Exception as e:
        error = f"{type(e).__name__}: {e}"
        if proc is not None:
            try:
                _stop_process(proc)
            except (OSError, subprocess.TimeoutExpired):
                error += "; review process could not be stopped"
        with JOBS_LOCK:
            _PROCS.pop(run_id, None)

    # Record the outcome under the lock. productization STEP 6: a governance
    # outcome (blocked, stopped_model_approval, stopped_redaction_gate,
    # refused_sensitivity_layer_inactive, snapshot_conflict, operator_abort) is
    # a distinct status, not "failed": the pipeline refused or paused ON
    # PURPOSE. A run timeout has no exit_code to map (still "failed", with the
    # timeout reason already in `error`); any other non-zero code not in the
    # map is a plain "failed". api STEP B2: a caller-requested cancel is its
    # OWN status, "cancelled", checked FIRST and never run through
    # _status_for_exit_code: terminate()/kill() leaves an arbitrary returncode
    # (negative on POSIX, platform-defined on Windows) that means nothing
    # under that table and must never be misread as a governance code or a
    # plain failure.
    with JOBS_LOCK:
        job = _find_job(run_id)
        if job is not None:
            if cancel_event.is_set():
                job["status"] = "cancelled"
            elif exit_code is None:
                job["status"] = "failed"
            else:
                job["status"] = _status_for_exit_code(exit_code)
            job["error"] = error
            job["exit_code"] = exit_code
            job["completed_at"] = _now_iso()
            _write_status(job)
        _CANCELLED.pop(run_id, None)

    # Auto-clear the placed ingested files (success OR failure), then drop the staging.
    # SHIMMER_AUTO_CLEAR=false leaves the placed files in input/context/ for inspection.
    if AUTO_CLEAR:
        if native_intake:
            _clear_standalone(created)
            if task == "draft" and proc is not None:
                _clear_system_draft()
        else:
            _auto_clear()
            _clear_system_draft()
    with JOBS_LOCK:
        staging = _STAGING.pop(run_id, None)
    if staging:
        shutil.rmtree(staging, ignore_errors=True)

    # Pick up the next queued job, if any.
    _start_next_job()


# ---------------------------------------------------------------------------
# api STEP A1: reading the STRUCTURED review back off a finished run.
#
# /runs/{run_id}/deliverables ships a zip of markdown and .docx: the right thing
# for a person, the wrong thing for a consumer program, which then has to parse
# prose to find out what the review actually decided. The three helpers below
# read the run's own artifacts and return the TYPED records instead:
#
#   the Finding records   live on the append-only message bus
#                         (<run>/logs/agent_bus.jsonl), inside the canonical
#                         envelope's items[] (INFRA-037). finding_record.is_finding
#                         decides what is one; nothing here re-implements that test.
#   the pairing map       lives at <run>/audit/pairing_map.json, one object per
#                         document, written at phase 5.5 before any judging.
#   the live counters     come from the pairing map (pairs planned) and from
#                         <run>/logs/cost_tracker.jsonl (one line per model call),
#                         both of which grow while the run is in flight, so a
#                         poller sees the review progressing rather than a
#                         binary queued/completed.
#
# All three read off DISK rather than out of JOBS, for the same reason
# _pending_approvals does: the artifacts are written by the pipeline SUBPROCESS,
# a different process from this server.
# ---------------------------------------------------------------------------
def _validated_run_dir(run_id):
    """The run folder for a caller-supplied run_id, or HTTPException(404).

    run_id is validated against the server's own mint format FIRST (exactly as
    every other run-scoped route does, _RUN_ID_RE) so a value like "../.." is
    rejected before it is ever used in a path expression. A well-formed id
    with no run folder is the same 404: a caller learns only "not found"
    either way."""
    if not _RUN_ID_RE.match(run_id):
        raise HTTPException(status_code=404, detail="run_id not found")
    run_dir = RUNS_DIR / run_id
    if not run_dir.is_dir():
        raise HTTPException(status_code=404, detail="run_id not found")
    return run_dir


def _project_finding(item, *, agent, doc_id):
    """One Finding record as a flat, stable API object.

    Field names are the Finding record's own (finding_record's module docstring).
    rule_id is read through finding_record.resolved_rule_id, which checks every
    real name an agent contract uses (rule_id, procedure_id, conv_id,
    convention_ref) plus the legacy claim_id; reading only one or two of those
    would silently drop findings whose producing agent uses a different name.
    source_refs falls back to ref_ids for records minted before those names
    settled. Both appear on real bus traffic."""
    import finding_record as _fr

    refs = item.get("source_refs")
    if not isinstance(refs, list):
        refs = item.get("ref_ids") if isinstance(item.get("ref_ids"), list) else []
    return {
        "agent": agent,
        "doc_id": doc_id,
        "item_id": item.get("item_id"),
        "revision": item.get("revision"),
        "rule_id": _fr.resolved_rule_id(item) or item.get("claim_id") or "",
        "source_rule_id": item.get("source_rule_id") or "",
        "unit_id": item.get("unit_id") or "",
        "relation": item.get("relation"),
        "record_verdict": item.get("record_verdict"),
        "value_a": item.get("value_a"),
        "unit_a": item.get("unit_a"),
        "value_b": item.get("value_b"),
        "unit_b": item.get("unit_b"),
        "source_refs": [str(r) for r in refs],
        "explanation": item.get("explanation") or "",
        # R6 / INFRA-044: the optional comparison fields of a prior-version record.
        "field_label": item.get("field_label") or "",
        "delta": item.get("delta"),
        "band_distance_change": item.get("band_distance_change"),
        "provenance": item.get("provenance") or "",
    }


def _bus_findings(run_dir):
    """Every Finding record on this run's bus, superseded revisions removed.

    INFRA-037: a higher `revision` for the same `item_id` supersedes the earlier
    one, which is how the verifiability gate downgrades an ungrounded finding
    (it appends revision+1 rather than editing the append-only bus). Returning
    both revisions would report a finding that the run has already withdrawn, so
    the last-highest revision per item_id wins and a record with no item_id is
    kept as-is (there is nothing to supersede it by). Order is bus order, which
    is chronological."""
    import finding_record as _fr

    bus = run_dir / "logs" / "agent_bus.jsonl"
    if not bus.is_file():
        return []
    out, by_item = [], {}
    try:
        lines = bus.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            continue  # a partially written last line while the run is live.
        body = msg.get("body")
        payload = body.get("payload") if isinstance(body, dict) else None
        items = payload.get("items") if isinstance(payload, dict) else None
        if not isinstance(items, list):
            continue
        agent = payload.get("agent") or msg.get("sender") or ""
        doc_id = payload.get("doc_id") or ""
        for item in items:
            if not _fr.is_finding(item):
                continue
            record = _project_finding(item, agent=agent, doc_id=doc_id)
            key = record["item_id"]
            if not key:
                out.append(record)
                continue
            prior = by_item.get(key)
            if prior is not None:
                prior_rev = prior["revision"] if isinstance(prior["revision"], int) else -1
                this_rev = record["revision"] if isinstance(record["revision"], int) else -1
                if this_rev < prior_rev:
                    continue
                out[out.index(prior)] = record
                by_item[key] = record
                continue
            by_item[key] = record
            out.append(record)
    return out


def _amendment_refusals_for_run(run_dir):
    """Every AMENDMENT_REFUSED event on this run's bus, flattened to one
    entry per refused finding.

    Found live: a real irregular finding (relation + record_verdict=irregular,
    genuinely computed, genuinely explaining a real problem) that
    amendment_from_finding could not turn into an amendment used to vanish
    with no trace anywhere. paired_review.ensure_amendments_for_findings now
    takes an optional refusal_sink and pipeline.py's phase_6_synthesis posts
    whatever lands in it as a distinct bus event, AMENDMENT_REFUSED, same
    envelope shape as every other posted item ({agent, doc_id, items}), never
    Finding-shaped (no relation/record_verdict pair _fr.is_finding would
    recognise), so _bus_findings correctly never surfaces these as findings:
    a refusal is not a finding, it is a record that one could not be acted
    on. Read-only, same file-read pattern as _bus_findings."""
    bus = run_dir / "logs" / "agent_bus.jsonl"
    if not bus.is_file():
        return []
    out = []
    try:
        lines = bus.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            continue
        body = msg.get("body")
        if not isinstance(body, dict) or body.get("event") != "AMENDMENT_REFUSED":
            continue
        payload = body.get("payload")
        items = payload.get("items") if isinstance(payload, dict) else None
        if not isinstance(items, list):
            continue
        doc_id = payload.get("doc_id") or ""
        for it in items:
            if not isinstance(it, dict):
                continue
            out.append({
                "doc_id": doc_id,
                "unit_id": it.get("unit_id"),
                "rule_id": it.get("rule_id"),
                "reason": it.get("reason") or "",
                "severity": it.get("severity"),
                "finding_stands": it.get("finding_stands"),
                "relation": (it.get("item") or {}).get("relation"),
                "explanation": (it.get("item") or {}).get("explanation") or "",
            })
    return out


def _contract_violations_for_run(run_dir):
    """Every CONTRACT_VIOLATION on this run's bus: a call whose output did not
    match its agent's own contract at all, so nothing usable was produced.

    Found live: PRACTICE_AUDITOR's real output tonight was mostly thin,
    assertions with no relation/record_verdict/explanation, valid enough to
    post but too bare to act on, and every one of those calls that fails
    outright (raises no valid item at all, this event) had nowhere a reader
    could see it either, the same invisibility the amendment-refusals route
    closed for a different case (a valid, irregular finding that could not
    become an amendment). This closes it for the other case: a call that
    produced NOTHING usable, not even a thin finding. Between the two
    routes, whatever a call produced now has a path to visibility: a real
    amendment, a refused finding, or a failed contract, never silently
    absent from all three.

    CONTRACT_VIOLATION carries no doc_id (agent_wrapper.py's own message
    shape, unlike AGENT_OUTPUT/AMENDMENT_REFUSED, which are per-document):
    a call can fail before the agent's response is ever attributed to one.
    Read-only, same file-read pattern as _bus_findings/_amendment_refusals_for_run."""
    bus = run_dir / "logs" / "agent_bus.jsonl"
    if not bus.is_file():
        return []
    out = []
    try:
        lines = bus.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            continue
        body = msg.get("body")
        if not isinstance(body, dict) or body.get("event") != "CONTRACT_VIOLATION":
            continue
        out.append({
            "agent": msg.get("sender") or "",
            "backend": body.get("backend") or "",
            "model": body.get("model") or "",
            "missing_fields": list(body.get("missing_fields") or []),
            "timestamp": msg.get("timestamp"),
        })
    return out


def _convention_assignment_for_run(run_dir):
    """This run's convention assignment as written by convention_assignment.
    write_assignment, or {"by_rule": {}, "by_agent": {}} if the run predates
    this route or never reached BOOT. Document-independent (computed once,
    before any document is in scope), unlike pairing_map, so there is no
    per-document key to read into. Same direct-file-read pattern as
    _pairing_map: the assignment is written once, at load, never rewritten
    mid-run, so a live bus read (the amendment-refusals/contract-violations
    pattern) would only ever see the same facts a plain file read already
    has, for extra cost; CONVENTION_UNASSIGNED on the bus exists for a
    reader that wants the unassigned rules specifically, without decoding
    the whole assignment."""
    path = run_dir / "audit" / "convention_assignment.json"
    if not path.is_file():
        return {"by_rule": {}, "by_agent": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"by_rule": {}, "by_agent": {}}
    if not isinstance(data, dict):
        return {"by_rule": {}, "by_agent": {}}
    return {"by_rule": data.get("by_rule") or {}, "by_agent": data.get("by_agent") or {}}


_UNDATED_EMPTY = {"undated": [], "excluded": [], "reviewed_anyway": [],
                  "note": ""}


def _undated_documents_for_run(run_dir):
    """This run's undated-document record as written by document_dating.
    write_undated_report, or empty lists for a run that predates it. Same
    direct-file-read pattern as _convention_assignment_for_run: written once at
    BOOT, never rewritten mid-run."""
    path = run_dir / "audit" / "undated_documents.json"
    if not path.is_file():
        return dict(_UNDATED_EMPTY)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return dict(_UNDATED_EMPTY)
    if not isinstance(data, dict):
        return dict(_UNDATED_EMPTY)
    return {"undated": data.get("undated") or [],
            "excluded": data.get("excluded") or [],
            "reviewed_anyway": data.get("reviewed_anyway") or [],
            "note": data.get("note") or ""}


def _pairing_map(run_dir):
    """This run's pairing map as written, keyed by document id, or {}."""
    path = run_dir / "audit" / "pairing_map.json"
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


# A custom SHIMMER_CONVENTION_REGISTRY, else the default location
# convention_parser.write_registry itself writes to. Overridable for the
# same reason SHIMMER_OUTPUT_DIR is: a test harness (tools/console_preview.py)
# needs to point this at its own throwaway registry rather than ever writing
# into the real repository's config/ directory.
CONVENTION_REGISTRY_PATH = Path(os.environ.get("SHIMMER_CONVENTION_REGISTRY")
                                 or (ROOT / "config" / "convention_registry.json"))


def _load_convention_registry():
    """The current convention registry (config/convention_registry.json, the
    same file convention_parser.write_registry produces, generated at BOOT
    from input/conventions/), or {} when it does not exist or does not parse.

    Read fresh on every call rather than cached at import: the registry can
    change between server starts (a fresh BOOT after input/conventions/ is
    edited) and this server process is long-lived, so a cached copy could go
    stale for the life of the process. The file is small (one JSON document
    of rule text) and this is called at most once per /pairs or /rules
    request, not in a hot loop."""
    if not CONVENTION_REGISTRY_PATH.is_file():
        return {}
    try:
        data = json.loads(CONVENTION_REGISTRY_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


# Same override pattern as CONVENTION_REGISTRY_PATH, for the same reason: a
# test harness (tools/console_preview.py) needs its own throwaway registry
# rather than ever reading the real repository's config/ directory.
AGENT_REGISTRY_PATH = Path(os.environ.get("SHIMMER_AGENT_REGISTRY")
                            or (ROOT / "config" / "agent_registry.json"))
# night W8: the nine-part agent harness (config/agent_harness.json, generated by
# scripts/build_agent_harness.py from the registry and the contracts) served to the
# console's Agents page by GET /harness. Same override reasoning as the registry.
AGENT_HARNESS_PATH = Path(os.environ.get("SHIMMER_AGENT_HARNESS")
                          or (ROOT / "config" / "agent_harness.json"))
HARNESS_PART_NAMES = (
    "agent_itself", "constitution_by_default", "rule_cluster",
    "testing_against_cluster", "ontology", "receive_format",
    "hand_format", "fires_at_all", "refire_condition_and_limit",
)


def _load_agent_registry_agents():
    """The current agent registry's own "agents" sub-dict (name -> spec,
    including each agent's declared `subjects`), or {} when it does not
    exist or does not parse. Read fresh on every call, same reasoning as
    _load_convention_registry: this server process is long-lived and the
    file can change between restarts."""
    if not AGENT_REGISTRY_PATH.is_file():
        return {}
    try:
        data = json.loads(AGENT_REGISTRY_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    agents = data.get("agents") if isinstance(data, dict) else None
    return agents if isinstance(agents, dict) else {}


def _pairs_view(pairing, convention_registry=None):
    """One document's pairing map with every document-derived string removed.

    Kept: the counts, the unit ids, the rule ids, and the REASON each rule was
    paired, rejected or left undecided (the reason is the whole point of the map:
    it is the record of why a rule was or was not applied).

    Dropped: `title` (the unit's own heading, lifted verbatim from the document),
    `fields_present` and `field_vocabulary` (the document's own field labels).
    `missing_field_findings` is reduced to a count, because those are Finding
    records and /runs/{run_id}/findings is where Finding records are served;
    shipping them in a second shape here would be two answers to one question.

    console fresh-eyes fix: a paired/rejected entry now also carries
    `source_rule_id`, the operator's own id for that rule (finding_record.
    source_rule_id_for, the SAME lookup a Finding record already uses to
    carry this, called here for the same reason). Before this fix the pairing
    map was the one place on this surface that showed a rule only by its
    registry number (CONV-001) while findings for the identical rule showed
    the operator's own id (CONV-A02) beside it: two numbering schemes for one
    rule on one screen. Empty string when the registry has no such rule (the
    function's own documented behavior), never invented."""
    import finding_record as _fr
    import pairing_map as _pairing_map
    registry = convention_registry if convention_registry is not None else {}

    def _paired_or_rejected(p):
        rid = p.get("rule_id")
        return {"rule_id": rid, "source_rule_id": _fr.source_rule_id_for(rid, registry),
                "reason": p.get("reason")}

    units = []
    for entry in pairing.get("units") or []:
        units.append({
            "unit_id": entry.get("unit_id"),
            "kind": entry.get("kind"),
            "paired": [_paired_or_rejected(p) for p in entry.get("paired") or []],
            "rejected": [_paired_or_rejected(p) for p in entry.get("rejected") or []],
            "undecided": list(entry.get("undecided") or []),
            # R6: integers only; the labels and reasons carry document text.
            "prior_hit_count": int((entry.get("prior_comparisons") or {}).get("hit_count") or 0),
            "prior_check_count": len((entry.get("prior_comparisons") or {}).get("checks") or []),
            "prior_refused_count": len((entry.get("prior_comparisons") or {}).get("refused") or []),
        })
    return {
        "document_id": pairing.get("document_id"),
        "unit_count": pairing.get("unit_count"),
        "rule_count": pairing.get("rule_count"),
        "pair_count": pairing.get("pair_count"),
        "rejected_count": pairing.get("rejected_count"),
        "undecided_count": pairing.get("undecided_count"),
        # Regenerate fixed diagnostic text; never echo arbitrary saved document
        # text through this new field. Older maps receive no retrospective claim.
        "semantic_pairing": _pairing_map.semantic_pairing_refusal(
            sum(len(e.get("undecided") or []) for e in pairing.get("units") or []))
            if pairing.get("semantic_pairing") else None,
        "unmatched_units": list(pairing.get("unmatched_units") or []),
        "missing_field_finding_count": len(pairing.get("missing_field_findings") or []),
        "units": units,
        # Convention distribution, step A: the plans phase 5.5 did NOT judge because
        # their rule has no convention-review consumer, and the computed plans it
        # re-attributed to a rule that has one. Structural only: unit ids, rule ids,
        # agent names and status words, never a passage of the document.
        "not_judged": [
            {"unit_id": r.get("unit_id"), "rule_id": r.get("rule_id"),
             "source_rule_id": _fr.source_rule_id_for(r.get("rule_id"), registry),
             "kind": r.get("kind"), "reason": r.get("reason"),
             "consumer_agents": list(r.get("consumer_agents") or []), "status": r.get("status")}
            for r in (pairing.get("not_judged") or [])],
        "not_judged_count": int(pairing.get("not_judged_count") or 0),
        "reattributed": [
            {"unit_id": r.get("unit_id"), "from_rule_id": r.get("from_rule_id"),
             "to_rule_id": r.get("to_rule_id"), "kind": r.get("kind")}
            for r in (pairing.get("reattributed") or [])],
    }


# The pipeline phase that runs the convention review. A cost_tracker line
# carrying this phase is a judging call; anything else is another phase's work.
_REVIEW_PHASE = "5.5"


def _model_call_counts(run_dir):
    """(total model calls, calls made in the review phase) from cost_tracker.jsonl.

    One line per call, appended as the run proceeds, so both numbers are live."""
    path = run_dir / "logs" / "cost_tracker.jsonl"
    if not path.is_file():
        return 0, 0
    total, in_phase = 0, 0
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return 0, 0
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            record = json.loads(line)
        except ValueError:
            continue
        total += 1
        if str(record.get("phase") or "") == _REVIEW_PHASE:
            in_phase += 1
    return total, in_phase


def _review_progress(run_dir, review_mode):
    """The three counters GET /runs/{run_id} adds, derived from the run's own artifacts.

      pairs_planned          every (unit, rule) pair the map decided could apply,
                             summed over the run's documents.
      model_calls            model calls made so far, all phases.
      pairs_arithmetic_only  pairs the run settled without asking a model, i.e.
                             planned pairs minus judging calls. This is meaningful
                             ONLY in paired mode, where a call is made per pair
                             that Python could not settle; in wide mode a phase-5.5
                             call is a whole-document review and subtracting it
                             from a pair count would be arithmetic on unlike
                             things, so it is reported as null rather than as a
                             number that looks true and is not."""
    planned = 0
    for pairing in _pairing_map(run_dir).values():
        if isinstance(pairing, dict) and isinstance(pairing.get("pair_count"), int):
            planned += pairing["pair_count"]
    total_calls, phase_calls = _model_call_counts(run_dir)
    arithmetic_only = None
    if review_mode == "paired":
        arithmetic_only = max(0, planned - phase_calls)
    return {"pairs_planned": planned,
            "pairs_arithmetic_only": arithmetic_only,
            "model_calls": total_calls}


# ---------------------------------------------------------------------------
# api STEP B1: the run resource. GET /runs/{run_id} and GET /runs report ONE
# object per run (_run_record), replacing the separate, thinner shapes the
# now-retired GET /status/{run_id} and GET /queue used to return (both
# removed in api STEP B5's route-naming pass, once GET /runs/{run_id} and
# GET /runs were already their strict supersets).
#
# The new object adds three things the old "status" string alone could not
# say at once: a closed-set `state` (queued / running / awaiting_approval /
# stopped / cancelled) that a caller's switch can be exhaustive over; an
# `outcome` (succeeded / governance_stop / crashed / timed_out) that is
# populated only once `state` is "stopped", so a governance halt is never
# reported the same way as a crash; and `pending_approval`, the full pending
# question (not just its existence), read off the SAME pending_approval.json
# _pending_approvals() already reads, so GET /runs/{run_id} never needs a
# second call to GET /approvals to explain why a run is stalled.
# ---------------------------------------------------------------------------
def _pending_approval_for(run_dir):
    """The pending governed question for ONE run, or None.
    _pending_approvals() (used by GET /approvals) now genuinely DELEGATES to
    this function (api STEP B5, fresh-eyes fix 1e/4d/4e): before that fix it
    reimplemented the same pending-vs-answered file check independently and
    returned a thinner shape; both routes now describe the identical pending
    record the same way. A pending_approval.json with no approval_decision.json
    yet means a human has not answered. Adds `message` (split out of `payload`, since payload may or
    may not carry one depending on the topic; message is what a person reads,
    payload is what a program reads, kept as separate fields rather than
    mixed, per the human/machine constraint) and `default_on_timeout` /
    `timeout_at`, computed from SHIMMER_APPROVAL_WAIT_S, the same environment
    variable the pipeline subprocess's file-operator handler already reads for
    this exact wait (server.py's own docstring table, SHIMMER_APPROVAL_WAIT_S
    row); the pipeline's handler unconditionally defaults to DEFERRED on
    timeout regardless of topic, so default_on_timeout is always that literal
    string, stated rather than left for a caller to infer from source."""
    pending_path = run_dir / "audit" / "pending_approval.json"
    decision_path = run_dir / "audit" / "approval_decision.json"
    if not pending_path.exists() or decision_path.exists():
        return None
    try:
        record = json.loads(pending_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    payload = record.get("payload") if isinstance(record.get("payload"), dict) else {}
    asked_at = record.get("asked_at")
    timeout_at = None
    if isinstance(asked_at, str):
        try:
            asked_dt = datetime.fromisoformat(asked_at)
            wait_s = _env_int("SHIMMER_APPROVAL_WAIT_S", 3600)
            timeout_at = (asked_dt + timedelta(seconds=wait_s)).isoformat()
        except ValueError:
            timeout_at = None
    return {
        "topic": record.get("topic"),
        "message": payload.get("message") if isinstance(payload.get("message"), str) else "",
        "payload": payload,
        "asked_at": asked_at,
        "default_on_timeout": "DEFERRED",
        "timeout_at": timeout_at,
    }


# Terminal `status` strings whose outcome is "governance_stop": the pipeline
# stopped itself ON PURPOSE. Identical set to GOVERNANCE_STATUSES above; kept
# as a separate name so a reader of _outcome_for_status does not have to trace
# back to the exit-code table to see which statuses land here.
_GOVERNANCE_OUTCOME_STATUSES = GOVERNANCE_STATUSES
# Terminal `status` strings whose outcome is "crashed" rather than a
# governance stop or a timeout. snapshot_conflict and operator_abort are
# distinct governance-adjacent outcomes upstream (see _EXIT_STATUS_MAP's own
# comment) but neither is a rule refusing on purpose mid-review the way the
# four GOVERNANCE_STATUSES are, and neither is "succeeded"; "crashed" is the
# nearest of the four `outcome` values and is recorded here explicitly rather
# than left to a catch-all, so the mapping is auditable in one place.
# "interrupted" (a server restart mid-run, STEP 2) is not a pipeline decision
# at all; it is mapped here too, to "crashed", for the same reason: there is
# no fifth `outcome` value for "the server died", and "crashed" is the
# closest true statement ("something other than success and other than a
# rule happened").
_CRASHED_OUTCOME_STATUSES = {"failed", "snapshot_conflict", "operator_abort", "interrupted"}


def _outcome_for_status(status, exit_code):
    """(outcome, stop_reason) for a TERMINAL `status` string. Only called once
    `state` has already been decided to be "stopped" (see _run_record); never
    called for "queued", "running" or "awaiting_approval"."""
    if status == "completed":
        return "succeeded", None
    if status in _GOVERNANCE_OUTCOME_STATUSES:
        return "governance_stop", {"code": status, "detail": None}
    if status == "failed" and exit_code is None:
        # _run_job never observes an exit_code on a run-timeout path (the
        # subprocess is terminated/killed by the Timer, not waited on for a
        # code); exit_code is None is exactly and only that path today.
        return "timed_out", {"code": "run_timeout", "detail": None}
    if status in _CRASHED_OUTCOME_STATUSES:
        return "crashed", {"code": status, "detail": None}
    # Unrecognised status string (should not happen; every writer of
    # job["status"] uses one of the names above or _status_for_exit_code's
    # own table). Reported as crashed rather than raising, since a status
    # route must never itself throw on an unexpected but real job record.
    return "crashed", {"code": status, "detail": None}


def _state_for_job(job, run_dir):
    """The closed-set `state` for one job: queued / running /
    awaiting_approval / stopped / cancelled. api STEP B2: POST
    /runs/{run_id}/cancel is the sole writer of job["status"] = "cancelled",
    for both a queued job (never started) and a running one (subprocess
    terminated)."""
    status = job.get("status")
    if status == "queued":
        return "queued"
    if status == "cancelled":
        return "cancelled"
    if status == "running":
        if _pending_approval_for(run_dir) is not None:
            return "awaiting_approval"
        return "running"
    return "stopped"


def _documents_for_run(run_id, run_dir):
    """One entry per document the pairing map knows about, each with its own
    status (in_progress / done) and deliverables_url.

    api STEP B4's own fresh-eyes read of this surface found this docstring
    previously promised a THIRD status, "not_started", that the code has
    never produced: a document only appears in this list once the pairing
    map has an entry for it at all, which only happens once phase 5.5 has
    already paired that document against the rule registry -- by the time
    an entry exists here, "not started" is no longer a state that document
    can be in. A document genuinely not started yet (queued behind others,
    or the run itself still in an earlier phase) is simply ABSENT from this
    list, not present with a not_started status; the docstring is corrected
    to the two values the code actually emits rather than inventing
    handling for a third value nothing here can ever produce.

    api STEP B4: deliverables_url is a REAL fetchable route
    (GET /runs/{run_id}/deliverables/{doc_id}), not a display string. Before
    this step it was a bare relative path ("case_a/"), true only as a
    location inside a zip the caller had already downloaded; a caller
    reading a status response had no way to act on it directly. Non-null
    only once BP-16's deliverables/<doc_id>/ exists and holds at least one
    file, exactly matching what the new per-document route itself requires
    before it will serve anything.

    A run with no pairing map yet (nothing has reached phase 5.5) returns an
    empty list, not an error: "no documents yet" and "unknown run" are
    different answers, matching the empty-but-200 convention every other
    run-scoped read on this surface already uses."""
    out = []
    deliv_root = run_dir / "deliverables"
    for pairing in _pairing_map(run_dir).values():
        if not isinstance(pairing, dict):
            continue
        doc_id = pairing.get("document_id")
        if not doc_id:
            continue
        doc_dir = deliv_root / doc_id
        done = doc_dir.is_dir() and any(p.is_file() for p in doc_dir.rglob("*"))
        out.append({
            "doc_id": doc_id,
            "status": "done" if done else "in_progress",
            "deliverables_url": f"/runs/{run_id}/deliverables/{doc_id}" if done else None,
        })
    return out


def _amendment_view(a):
    """One amendment, projected to the fields a reader deciding whether to
    accept a correction needs: the passage as it stands, the passage as
    proposed, the rule it rests on in the operator's own identifier, and the
    reasoning. Console fresh-eyes addition (the last thing the pipeline
    produces that no view showed): the operator's own requirement is that
    these four travel TOGETHER, since an unexplained correction is worth
    less than an explained one and a reader must be able to tell them apart,
    so nothing here is optional to include, only optional to be non-empty.

    original_text: the document's actual passage as of paired_review.py's
    amendment_from_finding fix (the source fix, not a display workaround).
    Two non-passage shapes exist on disk and both must be caught: the OLD
    pre-fix shape (original_text byte-equal to the finding's own unit_id,
    exactly what the old code wrote: str(item.get("unit_id") or
    document_level)), and the NEW fix's own fallback ("unit id %s (text not
    available)" % unit_id), which amendment_from_finding writes when
    unit_texts has no entry for this finding's unit_id, even after that
    function's own boundary repair (_repair_unit_id) has had a chance to
    resolve it. That miss is real and was found on a real run, not a
    hypothetical: a WIDE-mode agent (PRACTICE_AUDITOR) stated its own
    finding's unit_id as the document's own identifier for the record it was
    describing (e.g. "CAT-BIRCH", the Identifier: field value), not the
    pipeline's internal split_units id (e.g. "u02-record-cat-birch") that
    unit_texts is keyed by. Closed at three layers, in order of how much of
    the gap each one removes: the work payload now hands both convention-
    review agents the real id/title list (pipeline.py's document_units), the
    contract now tells them to copy from it (config/agent_contracts.json,
    finding_record.says.unit_id), and amendment_from_finding still tries one
    narrow, structural second chance for whatever a model gets wrong anyway,
    since a contract is asked for, never enforced. unit_id_repaired_to
    (below) says when that third layer is the reason a passage shows: absent
    on a direct hit or a genuine miss, present only when the repair fired.
    Detected by testing whether original_text equals the finding's own
    unit_id, OR matches the documented fallback template with that same
    unit_id substituted in: neither is pattern-guessing, both are exact
    reproductions of strings amendment_from_finding is known to write, so a
    real document passage cannot collide with either by chance.
    unit_id_repaired_to: the structural unit_id the boundary repair actually
    matched to, when it fired; null otherwise (direct hit or genuine miss).
    Passed straight through, not re-derived: the repair already happened in
    amendment_from_finding, this is only reporting it.
    proposed_text: null unless a model or --amendment-polish supplied one;
    passed through as null, never invented, the console's own job to say
    "no proposed wording" for that case.
    source_rule_id: the operator's own id (source_convention_ref, already
    stamped by finding_record.source_rule_id_for at write time for a
    computed amendment); convention_ref (the registry id) is the only
    honest fallback when absent, the same rule every other rule id on this
    surface already follows.
    comment: the reasoning. Required by both the computed and model-drafted
    contracts (agent_contracts.json's own "required" list for both paths),
    so this is never expected to be empty; if it somehow is, that is stated
    plainly rather than shown as a blank field."""
    original_text = a.get("original_text") or ""
    finding_unit_id = a.get("finding_unit_id")
    is_bare_unit_id = bool(finding_unit_id) and original_text == str(finding_unit_id)
    is_fallback_wrapper = (bool(finding_unit_id)
                           and original_text == "unit id %s (text not available)" % finding_unit_id)
    is_not_a_passage = is_bare_unit_id or is_fallback_wrapper
    return {
        "convention_ref": a.get("convention_ref"),
        "source_rule_id": a.get("source_convention_ref") or a.get("convention_ref"),
        "original_text": original_text,
        "original_text_is_passage": bool(original_text) and not is_not_a_passage,
        "proposed_text": a.get("proposed_text"),
        "comment": a.get("comment") or "",
        "action": a.get("action"),
        "severity": a.get("severity"),
        "finding_unit_id": a.get("finding_unit_id"),
        "finding_rule_id": a.get("finding_rule_id"),
        "unit_id_repaired_to": a.get("unit_id_repaired_to"),
        "ref_ids": list(a.get("ref_ids") or []),
        "derived_from": a.get("derived_from") or "",
    }


def _amendments_for_run(run_id, run_dir):
    """Every amendment across every DONE document of this run, read from
    each document's own deliverables/<doc_id>/review_data.json (BP-16, the
    same master file amendment_render.write_amendment_deliverables writes
    verbatim and review_findings.md/tracked_changes.docx are pure renders
    of). Read-only, non-mutating, the same pattern /findings and /pairs
    already use. A document still in_progress has no review_data.json yet
    (write_amendment_deliverables runs once per document, at the end of
    that document's own phase 6/9), so only done documents are read; an
    empty list is correct and expected until at least one document
    finishes, not an error."""
    import run_context as _rc
    out = []
    for doc in _documents_for_run(run_id, run_dir):
        if doc["status"] != "done":
            continue
        path = run_dir / "deliverables" / doc["doc_id"] / _rc.DELIVERABLE_FILENAMES["amendments_json"]
        if not path.is_file():
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        amendments = payload.get("amendments") if isinstance(payload, dict) else None
        if not isinstance(amendments, list):
            continue
        for a in amendments:
            if isinstance(a, dict):
                view = _amendment_view(a)
                view["doc_id"] = doc["doc_id"]
                out.append(view)
    return out


def _run_record(job, run_dir):
    """The complete run-resource object GET /runs/{run_id} and GET /runs
    return: everything decision one requires in one place, so a caller never
    needs a second call to understand a run's state, why it stopped (if it
    stopped), which documents are done, or what a pending approval is asking.

    api STEP B2: `state == "cancelled"` gets its own `outcome`, "cancelled" --
    a fifth value alongside the four stage-one defined (succeeded /
    governance_stop / crashed / timed_out). It is deliberately not folded
    into "crashed": a caller who asked for the stop must be able to tell
    that apart from one it did not ask for, and "succeeded" would be an
    outright false claim. `stop_reason` for a cancelled run names whether it
    was cancelled while queued (never started) or while running (subprocess
    terminated); `documents` on the same object shows whatever partial
    output the run produced before the stop -- cancelling deletes nothing on
    disk, it only stops further work, so the response says what survives
    rather than the caller having to guess."""
    state = _state_for_job(job, run_dir)
    outcome = None
    stop_reason = None
    if state == "stopped":
        outcome, stop_reason = _outcome_for_status(job.get("status"), job.get("exit_code"))
        if stop_reason is not None and stop_reason.get("detail") is None:
            stop_reason = dict(stop_reason, detail=job.get("error"))
    elif state == "cancelled":
        outcome = "cancelled"
        stop_reason = {"code": "cancelled",
                       "detail": job.get("error") or "cancelled by request"}
    # api STEP B5 (fresh-eyes fix 4a): _STATUS_FIELDS includes "status", the
    # job's raw internal string (still the actual field job["status"] IS
    # everywhere else in this file -- _state_for_job, cancellation,
    # approval-answering, and status.json on disk all still read and write
    # it, unchanged). It is deliberately EXCLUDED from this HTTP response:
    # returning both "status" and state/outcome/stop_reason side by side let
    # a caller read either vocabulary and the two could read as disagreeing
    # (e.g. status="blocked" beside state="stopped", outcome="governance_stop")
    # with nothing here to say which one to trust. state/outcome/stop_reason
    # is the sole vocabulary a caller of this response sees.
    record = {k: job.get(k) for k in _STATUS_FIELDS if k != "status"}
    if job.get("multi_round") is True:
        record["multi_round"] = True
    record["state"] = state
    record["outcome"] = outcome
    record["stop_reason"] = stop_reason
    record["pending_approval"] = (_pending_approval_for(run_dir)
                                  if state == "awaiting_approval" else None)
    record["documents"] = _documents_for_run(job["run_id"], run_dir)
    record["log_url"] = f"/runs/{job['run_id']}/log"
    # console fresh-eyes fix: whether a log exists must be knowable up front,
    # not only by making the GET and reading its status code. Without this
    # field the console's Log section could only ever be a bare "Load log"
    # button, silent about whether anything is behind it until clicked --
    # the exact silent-absence failure this surface exists to avoid,
    # reintroduced in the one section meant to explain every other one. Same
    # cheap on-disk check _documents_for_run already makes for deliverables/.
    record["has_log"] = (run_dir / "logs" / "pipeline_stdout.log").is_file()
    record.update(_review_progress(run_dir, job.get("review_mode")))
    return record


# ---------------------------------------------------------------------------
# ROUTES (the URLs the server answers). All are token-gated via verify_token.
# ---------------------------------------------------------------------------
@app.post("/submit", status_code=202, dependencies=[Depends(verify_token)])
async def submit(files: List[UploadFile] = File(default=None),
                 task: Optional[str] = Form(default=None),
                 question: Optional[str] = Form(default=None),
                 sensitive: Optional[str] = Form(default=None),
                 review_mode: Optional[str] = Form(default=None),
                 intake_mode: Optional[str] = Form(default=None),
                 review_targets: Optional[str] = Form(default=None),
                 prior_files: Optional[str] = Form(default=None),
                 multi_round: Optional[str] = Form(default=None),
                 multi_round_manifest: Optional[str] = Form(default=None),
                 input_language: Optional[str] = Form(default=None),
                 output_language: Optional[str] = Form(default=None),
                 agent_briefs: Optional[str] = Form(default=None),
                 confirmed: Optional[str] = Form(default=None)):
    """Accept a review or draft job.

    Multipart fields:
      - files:     the .md case files plus the _corpus_ingest.json sidecar. Required
                   for task=review; optional for task=draft (grounding may already sit
                   in input/context/, or be uploaded alongside the question).
      - task:      "review" (default, or SHIMMER_TASK) or "draft".
      - question:  the memo question/brief for task=draft (required there), or an
                   optional framing question for task=review (R6), forwarded to the
                   pipeline for either task, folded into every agent's run objectives
                   and echoed in the deliverables; never parsed by the code.
      - sensitive: (productization STEP 6 item 3) "true" or "false"; per-submission
                   privacy posture, defaulting to SHIMMER_SENSITIVE when omitted. false
                   (the common case) sends document text to cloud providers and waives
                   redaction for THIS run. true keeps redaction on, which today means
                   the run refuses to start (exit 6) because the LAW-IV masking layer
                   ships inactive; see the console's explanation text. The two override
                   flags (--sensitivity-layer-inactive-override, --no-redaction-override)
                   are appended in _run_job only when this job's resolved value is false,
                   exactly as the old blanket SHIMMER_SENSITIVE check did.
      - review_mode: (api STEP A1) "paired" or "wide". Omitted, it resolves the way
                   the pipeline resolves it with no --review-mode flag: paired under
                   the local backend profile, wide under cloud. Unlike `task`, an
                   unrecognised value is REJECTED with 400 rather than silently
                   falling back: the two modes differ by roughly an order of
                   magnitude in model calls, so quietly turning a typo'd "pared"
                   into a wide cloud run would spend the operator's money on a
                   mode they did not ask for.
      - intake_mode: explicitly "standalone" for ordinary operator documents,
                   or "integrated" for a prepared external bundle. Omitted,
                   retains the existing ingestion validator and SHIMMER_MODE.
      - review_targets / prior_files: JSON arrays of uploaded document filenames
                   for standalone intake. All other documents are grounding;
                   the wizard's parser detects review rules. Existing operator
                   instructions and differing files are preserved by refusal.
      - confirmed: exactly "true" for standalone intake. Its sensitive choice
                   must also be explicitly "true" or "false". The console only
                   sends uploads after the operator confirms the displayed plan.

    We write any uploads to a private temp dir, validate them against the corpus
    ingestion contract (when present), then queue the job. Files move into
    input/context/ only when the job starts (see _run_job)."""
    import tempfile  # local import: only /submit needs it.

    case_manifest = None
    import run_options
    try:
        language = run_options.normalize(input_language, output_language, agent_briefs)
    except ValueError:
        raise HTTPException(400, "Language requires input auto/en/tr and output en/tr; agent briefs require enabled/disabled.")
    if multi_round is not None or multi_round_manifest is not None:
        from multi_round import normalize_request
        try:
            if multi_round not in {"true", "false"}:
                raise ValueError()
            if multi_round_manifest is not None and len(multi_round_manifest) > 1000000:
                raise ValueError()
            case_manifest = normalize_request(multi_round == "true",
                json.loads(multi_round_manifest) if multi_round_manifest is not None else None)
            if case_manifest is not None and (case_manifest["fixture"] or task != "review" or sensitive != "false"):
                raise ValueError()
        except (ValueError, TypeError):
            raise HTTPException(400, "Multi-round needs an explicit Review request, Normal privacy, and a valid non-fixture case manifest.")

    if _STOPPING.is_set():
        raise HTTPException(503, "Shimmer is stopping. Start it again before submitting a review.")
    job_intake_mode = (intake_mode or MODE).strip().lower()
    native_intake = intake_mode is not None and job_intake_mode == "standalone"
    if job_intake_mode not in {"standalone", "integrated"}:
        raise HTTPException(400, "Choose ordinary documents or a prepared ingestion bundle.")
    targets = _filename_list(review_targets, "review_targets")
    prior = _filename_list(prior_files, "prior_files")
    if native_intake:
        if confirmed != "true":
            raise HTTPException(400, "Review the plan and confirm before starting. Nothing was submitted.")
        if sensitive not in {"true", "false"}:
            raise HTTPException(400, "Choose Normal or Sensitive before starting.")
    elif targets or prior:
        raise HTTPException(400, "Prepared bundles use their ingestion metadata. Choose ordinary documents to select review targets.")

    job_sensitive = SENSITIVE if sensitive is None else (
        sensitive.strip().lower() in {"1", "true", "yes", "y", "on"})
    if job_sensitive:
        from preflight import sensitive_readiness
        ready, detail = sensitive_readiness(ROOT)
        if not ready:
            raise HTTPException(409, detail)

    task = (task or TASK_DEFAULT).strip().lower()
    if task not in ("review", "draft"):
        if native_intake:
            raise HTTPException(400, "Choose Review or Draft before starting.")
        task = "review"

    if review_mode is None or not review_mode.strip():
        job_review_mode = _default_review_mode()
    else:
        job_review_mode = review_mode.strip().lower()
        if job_review_mode not in REVIEW_MODES:
            raise HTTPException(
                status_code=400,
                detail=f"review_mode must be one of {list(REVIEW_MODES)}, got {review_mode!r}")

    question = (question or "").strip()
    uploads = files or []
    if task == "draft" and not question:
        raise HTTPException(status_code=400, detail="task=draft requires a 'question' field")
    if task == "review" and not uploads:
        raise HTTPException(status_code=400, detail="task=review requires at least one uploaded file")

    # productization STEP 3: reject an oversized/over-count submission BEFORE any
    # staging directory or file is created, per file-count first (cheapest check).
    if len(uploads) > MAX_UPLOAD_FILES:
        raise HTTPException(
            status_code=400,
            detail=f"too many files: {len(uploads)} > SHIMMER_MAX_UPLOAD_FILES ({MAX_UPLOAD_FILES})")

    run_id = _new_run_id()
    staging = Path(tempfile.mkdtemp(prefix=f"ingest_{run_id}_"))
    try:
        names = []
        seen_names = set()
        total_bytes = 0
        max_file_bytes = MAX_UPLOAD_MB * 1024 * 1024
        max_total_bytes = MAX_UPLOAD_TOTAL_MB * 1024 * 1024
        for uf in uploads:
            name = _upload_name(uf.filename)
            if name.casefold() in seen_names:
                raise HTTPException(400, "Two selected files have the same name. Rename one and select them again.")
            seen_names.add(name.casefold())
            data = await uf.read()
            if len(data) > max_file_bytes:
                shutil.rmtree(staging, ignore_errors=True)
                raise HTTPException(
                    status_code=400,
                    detail=f"file {uf.filename!r} is {len(data)} bytes, over the "
                           f"SHIMMER_MAX_UPLOAD_MB ({MAX_UPLOAD_MB} MB) per-file cap")
            total_bytes += len(data)
            if total_bytes > max_total_bytes:
                shutil.rmtree(staging, ignore_errors=True)
                raise HTTPException(
                    status_code=400,
                    detail=f"submission exceeds SHIMMER_MAX_UPLOAD_TOTAL_MB "
                           f"({MAX_UPLOAD_TOTAL_MB} MB)")
            # Path(...).name strips any directory part from the client filename, so a
            # malicious name like "../../x" cannot escape the staging directory.
            dest = staging / name
            dest.write_bytes(data)
            names.append(dest.name)

        # Validate the staged bundle ONLY when files were uploaded (a draft with no
        # files has nothing to validate; its grounding already sits in input/context/).
        if native_intake:
            _standalone_plan(staging, task, targets, prior)
        elif names:
            proc = subprocess.run(
                [sys.executable, "-X", "utf8", str(VALIDATOR), "--target", str(staging)],
                capture_output=True, text=True, encoding="utf-8", errors="replace",
            )
            if proc.returncode != 0:
                # Reject: clean up the staging directory and return the violation report.
                shutil.rmtree(staging, ignore_errors=True)
                raise HTTPException(
                    status_code=400,
                    detail={"error": "contract validation failed",
                            "report": (proc.stdout or "") + (proc.stderr or "")},
                )
    except HTTPException:
        shutil.rmtree(staging, ignore_errors=True)
        raise  # already a clean 400, re-raise as-is.
    except Exception as e:
        shutil.rmtree(staging, ignore_errors=True)
        raise HTTPException(status_code=400, detail=f"could not accept upload: {e}")

    # Validation passed: register the staging dir and queue the job.
    with JOBS_LOCK:
        if _STOPPING.is_set():
            shutil.rmtree(staging, ignore_errors=True)
            raise HTTPException(503, "Shimmer stopped while checking the files. Start it again and submit the plan.")
        _STAGING[run_id] = staging
        new_job = {
            "run_id": run_id,
            "status": "queued",
            "task": task,
            "question": question,
            "sensitive": job_sensitive,
            "review_mode": job_review_mode,
            "intake_mode": job_intake_mode,
            "review_targets": targets,
            "prior_files": prior,
            "native_intake": native_intake,
            "input_language": language.input_language,
            "output_language": language.output_language,
            "agent_briefs": language.agent_briefs,
            "progress": None,
            "submitted_at": _now_iso(),
            "started_at": None,
            "completed_at": None,
            "exit_code": None,
            "error": None,
            "files": names,
        }
        if case_manifest is not None:
            # Kept in this run's audit folder, never ingested as corpus text.
            from run_context import for_run_dir
            import multi_round as multi_round_mod
            case_ctx = for_run_dir(ROOT, RUNS_DIR / run_id)
            try:
                multi_round_mod.begin(case_ctx, case_manifest)
                (case_ctx.audit_dir() / "multi_round_request.json").write_text(
                    json.dumps(case_manifest, ensure_ascii=False), encoding="utf-8")
            except OSError:
                _STAGING.pop(run_id, None)
                shutil.rmtree(staging, ignore_errors=True)
                raise HTTPException(500, "Could not save the case request. No model work was queued.")
            new_job["multi_round"] = True
        JOBS.append(new_job)
        _write_status(new_job)
    _start_next_job()
    return {"run_id": run_id, "status": "queued", "task": task, "sensitive": job_sensitive,
            "review_mode": job_review_mode, "files": names, "intake_mode": job_intake_mode}


@app.get("/runs/{run_id}", dependencies=[Depends(verify_token)])
async def run_detail(run_id: str):
    """api STEP B1 (route naming unified in STEP B5): the complete run
    resource. This route REPLACES the retired GET /status/{run_id} entirely
    (removed in api STEP B5's route-naming pass: every run-scoped route now
    lives under /runs/{run_id}/..., and this one, the run's own detail, is
    what /status/{run_id} used to answer a thinner version of -- a caller
    that reads a job's status now reads it HERE, via `state`/`outcome`, not
    at a separate path). A malformed id or an unknown one is 404 either way,
    so a caller learns nothing about which case it was."""
    if not _RUN_ID_RE.match(run_id):
        raise HTTPException(status_code=404, detail="run_id not found")
    with JOBS_LOCK:
        job = _find_job(run_id)
        if job is None:
            raise HTTPException(status_code=404, detail="run_id not found")
        job = dict(job)  # a copy, so the caller cannot mutate our record.
    return _run_record(job, RUNS_DIR / run_id)


# api STEP B2: how long POST /cancel waits for a RUNNING job's terminal write
# before answering, so the response reflects what actually happened rather
# than a promise. terminate() is normally fast; this is a ceiling, not an
# expected wait, and mirrors the 10s grace period _on_timeout already gives
# proc.wait() before escalating to kill().
_CANCEL_WAIT_S = 10.0


@app.post("/runs/{run_id}/cancel", dependencies=[Depends(verify_token)])
async def cancel_run(run_id: str):
    """api STEP B2: stop a run. A queued job is removed from the queue before
    it ever starts (no subprocess exists yet); a running job's subprocess is
    terminated (then killed, mirroring the existing run-timeout sequence).
    Both land on job["status"] = "cancelled", the sole writer of that status.
    A run already in a terminal state (stopped, or already cancelled) is
    refused with 409 and a reason naming its actual state, rather than a
    silent no-op: the caller asked for a state change that cannot happen,
    and is told so rather than left to infer it from an unchanged response.
    Deletes nothing on disk; whatever partial output exists stays where it
    is (see the `documents` field of the returned record)."""
    if not _RUN_ID_RE.match(run_id):
        raise HTTPException(status_code=404, detail="run_id not found")

    with JOBS_LOCK:
        job = _find_job(run_id)
        if job is None:
            raise HTTPException(status_code=404, detail="run_id not found")
        current_status = job["status"]

        if current_status == "queued":
            # Never started: no subprocess exists, nothing to terminate.
            # Remove its staging dir too, same as a finished run's cleanup.
            job["status"] = "cancelled"
            job["error"] = "cancelled before it started"
            job["completed_at"] = _now_iso()
            _write_status(job)
            staging = _STAGING.pop(run_id, None)
            record = _run_record(dict(job), RUNS_DIR / run_id)
            was_running = False
        elif current_status == "running":
            staging = None
            was_running = True
        else:
            raise HTTPException(
                status_code=409,
                detail=f"run_id {run_id!r} cannot be cancelled: its state is "
                       f"{current_status!r}, not queued or running")

    if not was_running:
        if staging:
            shutil.rmtree(staging, ignore_errors=True)
        # A cancelled QUEUED job never occupied the one-at-a-time slot, so the
        # next queued job (if any) is picked up exactly as it would be after
        # any other terminal transition.
        _start_next_job()
        return record

    # RUNNING: find the registered subprocess handle. A running job's Popen
    # is registered by _run_job the instant it exists (api STEP B2's _PROCS);
    # the only window where "running" and "no _PROCS entry" can both be true
    # is the brief gap between _start_next_job flipping the status and
    # _run_job reaching its own Popen call, so this polls briefly rather than
    # failing on a race that is not a real absence.
    proc = None
    cancel_event = None
    deadline = time.monotonic() + 2.0
    while time.monotonic() < deadline:
        with JOBS_LOCK:
            proc = _PROCS.get(run_id)
            cancel_event = _CANCELLED.get(run_id)
        if proc is not None and cancel_event is not None:
            break
        time.sleep(0.02)
    if proc is None or cancel_event is None:
        # The run finished (or crashed) in the time it took to look; nothing
        # left to cancel. Report its actual current state rather than a
        # cancellation that did not happen.
        with JOBS_LOCK:
            job = _find_job(run_id)
            job = dict(job) if job is not None else None
        if job is None:
            raise HTTPException(status_code=404, detail="run_id not found")
        raise HTTPException(
            status_code=409,
            detail=f"run_id {run_id!r} finished before the cancel request reached it; "
                   f"its state is now {job.get('status')!r}")

    cancel_event.set()
    proc.terminate()
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()

    # Wait (bounded) for _run_job's own thread to finish writing the terminal
    # status, so the response reflects what happened rather than a promise.
    deadline = time.monotonic() + _CANCEL_WAIT_S
    while time.monotonic() < deadline:
        with JOBS_LOCK:
            job = _find_job(run_id)
            status_now = job.get("status") if job is not None else None
        if status_now not in ("running", "queued"):
            break
        time.sleep(0.02)

    with JOBS_LOCK:
        job = _find_job(run_id)
        job = dict(job) if job is not None else None
    if job is None:
        raise HTTPException(status_code=404, detail="run_id not found")
    return _run_record(job, RUNS_DIR / run_id)


@app.post("/runs/{run_id}/approval", dependencies=[Depends(verify_token)])
async def answer_approval(run_id: str, body: dict):
    """api STEP B3: record a human's decision on one run's pending governed
    question.

    Body: {"decision": "...", "rationale": "..."}. `decision` is required and
    non-empty; `rationale` is optional. The value of `decision` is written
    through VERBATIM, never validated against a fixed enum here: the code
    that decides whether a decision counts as an approval
    (model_registry.enforce_current_models / constitution_guard._is_approved)
    already exists, is read back by the pipeline SUBPROCESS's own polling
    file-operator handler, and is not duplicated or second-guessed here.

    FIRST GOVERNANCE CONSTRAINT: this route WRITES the decision and nothing
    else. It never imports model_registry or constitution_guard, never calls
    _is_approved, never itself changes a run's state. Whether the run
    actually resumes, and which way the gate went, is decided entirely by
    the pipeline subprocess the next time its poll loop reads this file
    (_make_file_operator_handler, roughly every 2 seconds); this route
    cannot see or wait for that, only write the file the poll loop reads.

    SECOND GOVERNANCE CONSTRAINT: the response says the decision was
    RECORDED, never that it was approved. It carries `recorded: true` and
    `run_state`, the run's state as it stood the instant BEFORE this write
    (deliberately read before, not after: _pending_approval_for reports
    "awaiting_approval" only while approval_decision.json does not yet
    exist, so reading run_state after writing that file would report
    "running" -- correctly, since nothing is pending anymore, but that would
    silently answer a different question than "what was true when the
    caller asked"; the response is about the request that was just made, not
    about a race against the pipeline's next poll) -- never a claim about
    what the decision meant or what happened as a result. A caller that
    wants to see the EFFECT of the decision polls GET /runs/{run_id}
    afterward, exactly as it would for any other state change on this
    surface.

    404 for a malformed run_id, or a well-formed one with no pending
    approval on disk at all. 409 if this exact approval has ALREADY been
    answered: a decision file already sitting beside the pending file means
    a human answered this escalation once already (the pipeline's own
    handler deletes any stale decision file before writing the NEXT
    pending_approval.json for a later escalation, so "both files present"
    is unambiguous: this one was already answered and not yet consumed).
    400 if `decision` is missing or empty."""
    if not _RUN_ID_RE.match(run_id):
        raise HTTPException(status_code=404, detail="run_id not found")
    run_dir = RUNS_DIR / run_id
    audit_dir = run_dir / "audit"
    pending_path = audit_dir / "pending_approval.json"
    decision_path = audit_dir / "approval_decision.json"
    if not pending_path.exists():
        raise HTTPException(status_code=404, detail="no pending approval for this run_id")
    if decision_path.exists():
        raise HTTPException(
            status_code=409,
            detail=f"run_id {run_id!r} already has a recorded decision for this "
                   f"approval; answering the same pending question twice is refused")

    decision = str(body.get("decision", "")).strip()
    rationale = str(body.get("rationale", "")).strip()
    if not decision:
        raise HTTPException(status_code=400, detail="'decision' is required")

    # run_state is read BEFORE the write below, not after: _pending_approval_for
    # (and so _state_for_job) reads "awaiting_approval" precisely because
    # decision_path does not exist yet; the write below is what answers the
    # question, so the state that was TRUE going into this call -- the run was
    # genuinely waiting -- is what the response reports, not a state computed
    # a moment later that the write itself would have already changed.
    with JOBS_LOCK:
        job = _find_job(run_id)
        run_state = _state_for_job(dict(job), run_dir) if job is not None else None

    decided_at = _now_iso()
    record = {"decision": decision, "rationale": rationale, "decided_at": decided_at}
    audit_dir.mkdir(parents=True, exist_ok=True)
    tmp = decision_path.with_suffix(decision_path.suffix + ".tmp")
    tmp.write_text(json.dumps(record, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(decision_path)

    return JSONResponse(status_code=202, content={
        "run_id": run_id,
        "recorded": True,
        "decision": decision,
        "rationale": rationale,
        "decided_at": decided_at,
        "run_state": run_state,
    })


def _zip_dir(source_dir):
    """Zip every file under source_dir into an in-memory buffer, arcnames
    relative to source_dir (so BP-16's <doc_id>/ subfolders are preserved
    when source_dir is deliverables/, and a single document's own files sit
    at the zip root when source_dir is deliverables/<doc_id>/). Returns a
    seeked-to-0 BytesIO."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in source_dir.rglob("*"):
            if p.is_file():
                zf.write(p, arcname=str(p.relative_to(source_dir)))
    buf.seek(0)
    return buf


@app.get("/runs/{run_id}/deliverables", dependencies=[Depends(verify_token)])
async def deliverables(run_id: str):
    """api STEP B4: download a run's deliverables as a single .zip.

    Replaces the completion gate GET /results/{run_id} used (400 until
    job["status"] == "completed") with one grounded in what GET
    /runs/{run_id} already shows: `documents[]` there says exactly which
    documents are "done" and which are not, so a caller who already knows
    (from that call) that some documents are ready is never blocked from
    fetching them just because the run overall is not finished yet.

    Zips every existing file under deliverables/, including the root summary
    and partial document folders, rather than requiring the
    whole run to be complete first. A run that stopped early (crashed,
    cancelled, timed out) may leave a PARTIAL archive: fewer documents than
    were originally submitted, or a document folder missing files a
    completed run would have written. This is said explicitly, not left for
    the caller to discover by counting: the response carries an
    `X-Shimmer-Partial: true` header whenever `state` is not
    ("stopped" and outcome == "succeeded"), and the same fact is folded into
    the filename itself (`..._partial.zip` vs `..._deliverables.zip`), so it
    survives even if a caller only logs the filename and drops headers.

    404 for a malformed or unknown run_id, or one with NOTHING at all under
    deliverables/ yet (nothing to zip). No completion requirement otherwise:
    a queued or running run with zero documents done yet is also 404 (there
    is truly nothing to serve), which reads identically to "unknown run" by
    design, matching every other run-scoped route's 404 convention on this
    surface."""
    if not _RUN_ID_RE.match(run_id):
        raise HTTPException(status_code=404, detail="run_id not found")
    with JOBS_LOCK:
        job = _find_job(run_id)
        job = dict(job) if job is not None else None
    if job is None:
        raise HTTPException(status_code=404, detail="run_id not found")

    run_dir = RUNS_DIR / run_id
    deliv_dir = run_dir / "deliverables"
    if not deliv_dir.is_dir() or not any(deliv_dir.rglob("*")):
        raise HTTPException(status_code=404, detail="no deliverables exist yet for this run")

    record = _run_record(job, run_dir)
    is_partial = not (record.get("state") == "stopped" and record.get("outcome") == "succeeded")

    buf = _zip_dir(deliv_dir)
    suffix = "partial" if is_partial else "deliverables"
    return StreamingResponse(
        buf, media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="{run_id}_{suffix}.zip"',
            "X-Shimmer-Partial": "true" if is_partial else "false",
        },
    )


@app.get("/runs/{run_id}/deliverables/{doc_id}", dependencies=[Depends(verify_token)])
async def document_deliverables(run_id: str, doc_id: str):
    """api STEP B4: download ONE document's deliverables as a .zip, without
    fetching the whole run.

    This is the route `documents[].deliverables_url` on GET /runs/{run_id}
    points at (stage one built that reference; this route is what makes it
    fetchable rather than a display string). Closes the gap named directly:
    before this, reading a single finding meant downloading the whole
    archive and opening it locally, even for a run with many documents
    where only one was of interest.

    doc_id is NOT validated against _RUN_ID_RE (it is a document id, not a
    run id, with no fixed mint format); instead it is resolved as
    deliverables/<doc_id>/ under the run's OWN directory and rejected with
    404 if that exact subfolder does not exist or is empty -- doc_id is
    never used to construct a path outside deliverables/<run_id>/ because
    Path(...).name-style traversal is moot here: the path is built by
    joining a fixed parent (run_dir / "deliverables") with the literal
    doc_id segment and then checking .is_dir() at that exact location, so a
    doc_id containing ".." resolves outside deliverables/ and is caught by
    the same "does this exact path exist and is it a directory" check as
    any other wrong id, not specially.

    404 for a malformed or unknown run_id, or a run_id with no such
    document (whether the run never had it, or that document has not
    finished yet -- both are simply "not found here" from this route's
    point of view; GET /runs/{run_id}'s own `documents[]` is where a caller
    learns WHICH state a not-yet-ready document is in)."""
    if not _RUN_ID_RE.match(run_id):
        raise HTTPException(status_code=404, detail="run_id not found")
    with JOBS_LOCK:
        job = _find_job(run_id)
    if job is None:
        raise HTTPException(status_code=404, detail="run_id not found")

    doc_dir = (RUNS_DIR / run_id / "deliverables" / doc_id).resolve()
    deliv_root = (RUNS_DIR / run_id / "deliverables").resolve()
    if deliv_root not in doc_dir.parents and doc_dir != deliv_root:
        raise HTTPException(status_code=404, detail="document not found for this run")
    if not doc_dir.is_dir() or not any(doc_dir.rglob("*")):
        raise HTTPException(status_code=404, detail="document not found for this run")

    buf = _zip_dir(doc_dir)
    return StreamingResponse(
        buf, media_type="application/zip",
        headers={"Content-Disposition":
                 f'attachment; filename="{run_id}_{doc_id}.zip"'},
    )


@app.get("/runs/{run_id}/log", dependencies=[Depends(verify_token)])
async def run_log(run_id: str):
    """api STEP B4: the run's complete merged stdout/stderr log, as plain
    text, streamed from disk. This is what `log_url` on GET /runs/{run_id}
    has pointed at since stage one; before this route existed that field was
    a promise with nothing behind it.

    _run_job already writes every line to <run>/logs/pipeline_stdout.log as
    it arrives (never buffered fully in memory server-side, per the
    existing comment at that write site); this route streams the same file
    from disk rather than holding it in memory, so serving a long-running
    run's log costs no more here than it already did to write it.

    404 for a malformed or unknown run_id, or one with no log file yet (a
    queued run that has not started, or a run whose subprocess never
    produced output before exiting)."""
    if not _RUN_ID_RE.match(run_id):
        raise HTTPException(status_code=404, detail="run_id not found")
    with JOBS_LOCK:
        job = _find_job(run_id)
    if job is None:
        raise HTTPException(status_code=404, detail="run_id not found")

    log_path = RUNS_DIR / run_id / "logs" / "pipeline_stdout.log"
    if not log_path.is_file():
        raise HTTPException(status_code=404, detail="no log written yet for this run")

    def _stream():
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                yield line

    return StreamingResponse(_stream(), media_type="text/plain")


@app.get("/runs/{run_id}/findings", dependencies=[Depends(verify_token)])
async def findings(run_id: str):
    """api STEP B5: renamed from GET /findings/{run_id} (removed) to unify
    every run-scoped route under /runs/{run_id}/..., closing the naming
    split the fresh-eyes read found (a caller could no longer guess this
    route's path from the pattern of /runs/{run_id}/deliverables and the
    other newer routes). No change to what this route accepts, computes or
    returns -- the run's typed Finding records as JSON: the structured review itself.

    One object per finding, carrying the registry rule id and the OPERATOR's own
    rule id for it, the unit the finding is about, both figures with their units,
    the relation, the record verdict, the REF-*/WEB-REF-* ids it rests on, and the
    human-facing explanation. Superseded revisions are already removed
    (_bus_findings). Same token gate and the same run_id validation as every other
    run-scoped route; an unknown or malformed run_id is 404.

    A run with no findings yet (still early, or genuinely clean) is a 200 with an
    empty list, not a 404: "nothing found" and "no such run" are different answers
    and a poller must be able to tell them apart."""
    run_dir = _validated_run_dir(run_id)
    records = _bus_findings(run_dir)
    return {"run_id": run_id, "count": len(records), "findings": records}


@app.get("/runs/{run_id}/pairs", dependencies=[Depends(verify_token)])
async def pairs(run_id: str):
    """api STEP B5: renamed from GET /pairs/{run_id} (removed), same reason
    as GET /runs/{run_id}/findings above -- unifying every run-scoped route
    under /runs/{run_id}/.... No change to behavior: the run's pairing map,
    which rules could apply to which units, and why.

    One entry per document, each carrying the counts and, per unit, the rules
    paired / rejected / left undecided with the reason recorded for each. Carries
    no document text (see _pairs_view for exactly what is dropped and why). A run
    whose map was never written (a wide-mode run that failed before phase 5.5)
    is a 200 with an empty documents list."""
    run_dir = _validated_run_dir(run_id)
    registry = _load_convention_registry()
    docs = [_pairs_view(p, registry) for p in _pairing_map(run_dir).values() if isinstance(p, dict)]
    return {"run_id": run_id, "document_count": len(docs), "documents": docs}


@app.get("/runs/{run_id}/amendments", dependencies=[Depends(verify_token)])
async def amendments(run_id: str):
    """console fresh-eyes addition: the last thing the pipeline produces
    that no view showed. An amendment (a proposed correction, tied to a
    Finding) is written to deliverables/<doc_id>/review_data.json for every
    document that finishes phase 6, shipped in every archive, and until this
    route existed, never answerable by any API call: a reviewer who wanted
    to see the correction the system actually proposed had to download the
    archive and open the file by hand.

    Read-only, non-mutating, same pattern as /findings and /pairs: reads
    whatever is already on disk for every DONE document of this run (a
    document still in_progress has no review_data.json yet). 404 for a
    malformed/unknown run_id. 200 with an empty list, not an error, when no
    document has finished yet or no document produced an irregular finding
    (an amendment only exists for one, amendment_from_finding's own gate):
    "nothing produced" and "unknown run" are different answers, matching the
    empty-but-200 convention every other run-scoped read here already uses."""
    run_dir = _validated_run_dir(run_id)
    items = _amendments_for_run(run_id, run_dir)
    return {"run_id": run_id, "count": len(items), "amendments": items}


@app.get("/runs/{run_id}/amendment-refusals", dependencies=[Depends(verify_token)])
async def amendment_refusals(run_id: str):
    """A real, irregular finding the pipeline could not turn into an
    amendment, named plainly rather than left to vanish.

    Found live: PRACTICE_AUDITOR wrote genuinely irregular findings whose
    rule id landed under a field name amendment_from_finding did not yet
    recognise (config/agent_contracts.json declares four different names
    for the same concept across four agents); before this route and its
    underlying fix, every one of those findings was silently dropped, with
    nothing on the bus, nothing in a deliverable, nothing here, saying it
    had ever existed. The rule-id-alias fix (finding_record.resolved_rule_id)
    closes the specific cause found tonight; this route exists for whatever
    reason a future finding still cannot be built from, so a reader can tell
    "nothing was wrong" from "something was wrong and the pipeline could not
    act on it" instead of both looking identical (an empty amendments list).

    Read-only, non-mutating, reads the bus the same way /findings and /pairs
    do. 404 for a malformed/unknown run_id. 200 with an empty list, not an
    error, when nothing was refused: the common, expected case."""
    run_dir = _validated_run_dir(run_id)
    items = _amendment_refusals_for_run(run_dir)
    return {"run_id": run_id, "count": len(items), "refusals": items}


@app.get("/runs/{run_id}/contract-violations", dependencies=[Depends(verify_token)])
async def contract_violations(run_id: str):
    """A call whose output did not match its agent's own contract at all, so
    nothing usable was produced, not even a thin finding.

    Found live: after finding_record's fields were made required for
    PRACTICE_AUDITOR (relation, record_verdict, explanation, closing a
    different gap where most of its real output asserted a violation with no
    supporting content), the honest next question is what a stricter
    contract costs: some calls that used to pass a looser bar now genuinely
    fail it. This route, together with /runs/{run_id}/amendment-refusals,
    closes the last gap in visibility: a call now produces exactly one of
    three outcomes a reader can see somewhere, a real amendment, a refused
    finding, or a failed contract, never silently absent from all three.

    Read-only, non-mutating, reads the bus the same way /findings, /pairs
    and /amendment-refusals do. 404 for a malformed/unknown run_id. 200 with
    an empty list, not an error, when nothing failed its contract, the
    common, expected case."""
    run_dir = _validated_run_dir(run_id)
    items = _contract_violations_for_run(run_dir)
    return {"run_id": run_id, "count": len(items), "violations": items}


@app.get("/runs/{run_id}/undated-documents", dependencies=[Depends(verify_token)])
async def undated_documents_route(run_id: str):
    """The documents this run could not date, and which of those therefore
    went unreviewed.

    A document with no resolvable date fails the review cutoff
    (review_scope.apply_cutoff keeps dates at or after the cutoff, and None is
    never at or after anything), so it leaves the operational set. That used to
    happen silently, and a document that was never reviewed was indistinguishable
    in the output from one that was reviewed and produced no findings. This is
    the SAME visibility discipline as /runs/{run_id}/convention-assignment,
    /amendment-refusals and /contract-violations: an outcome a reader can see,
    rather than a decision that silently goes nowhere.

    `excluded` is the load-bearing list (undated AND not under review).
    `reviewed_anyway` is an undated document an operator manifest still put
    under review, which is not a silent drop.

    Read-only, non-mutating, reads this run's own audit/undated_documents.json
    directly (written once at BOOT, never rewritten mid-run). 404 for a
    malformed/unknown run_id. 200 with empty lists, not an error, for a run
    that predates this route."""
    run_dir = _validated_run_dir(run_id)
    data = _undated_documents_for_run(run_dir)
    return {"run_id": run_id,
            "undated": data["undated"],
            "excluded": data["excluded"],
            "reviewed_anyway": data["reviewed_anyway"],
            "undated_count": len(data["undated"]),
            "excluded_count": len(data["excluded"]),
            "note": data["note"]}


@app.get("/runs/{run_id}/convention-assignment", dependencies=[Depends(verify_token)])
async def convention_assignment_route(run_id: str):
    """The convention assignment computed once at this run's BOOT
    (docs/api/CONVENTION_ASSIGNMENT_DESIGN.md): a one-way subject label on
    each side (each agent's own declared subjects, each rule's own bracket
    tags), compared by code that names no subject itself. Per rule:
    subjects, matched agents, which of those have a live rule-consuming
    path (consumer_agents), and status (untagged / assigned /
    assigned_no_consumer / unassigned). Per agent: the rule ids it matched.

    A rule matching no agent, or matching only an agent with no consuming
    path today, is never dropped: it is the SAME visibility discipline as
    /runs/{run_id}/amendment-refusals and /contract-violations, one more
    outcome a reader can see rather than a routing decision that silently
    goes nowhere. The mirror case, an agent that declares a subject but
    matched nothing this load, is `idle_agents`: each entry names the
    agent and the subjects it declares, read against the CURRENT
    config/agent_registry.json (agent declarations are not per-run data,
    unlike the assignment itself, so this is the live file, the same
    reasoning /rules/{rule_id} already uses for the convention registry).

    Read-only, non-mutating, reads this run's own audit/
    convention_assignment.json directly (written once at BOOT, never
    rewritten mid-run, so there is nothing further for a live bus read to
    add over the file itself). 404 for a malformed/unknown run_id. 200 with
    an empty by_rule/by_agent/idle_agents, not an error, for a run that
    predates this route or never reached BOOT."""
    import convention_assignment as _ca

    run_dir = _validated_run_dir(run_id)
    data = _convention_assignment_for_run(run_dir)
    agents = _load_agent_registry_agents()
    idle = _ca.idle_agents_summary(data, agents)
    # night W8: the W3 firing gate's own answer for this assignment (the agents
    # phase 5.5 did not dispatch in wide mode), and how many rules were untagged
    # (those go to every convention-review agent, today's routing). Both come from
    # convention_assignment, the module the pipeline's gate delegates to, so the
    # console shows the gate's decision, not a second computation of it.
    return {"run_id": run_id, "rule_count": len(data["by_rule"]),
            "by_rule": data["by_rule"], "by_agent": data["by_agent"],
            "idle_agents": idle,
            "untagged": _ca.untagged_count(data),
            "not_firing": _ca.not_firing_convention_review_agents(data)}


@app.get("/harness", dependencies=[Depends(verify_token)])
async def agent_harness():
    """night W8: the nine-part agent harness (night W4), one entry per agent,
    as built by scripts/build_agent_harness.py into config/agent_harness.json
    (or SHIMMER_AGENT_HARNESS). Not run-scoped: the harness describes what an
    agent IS, generated from the registry and the contracts, and does not vary
    per run. Read fresh on every call, the same reasoning as the registries.

    `unresolved` lists, per agent, the parts still marked decided:false (each
    carries its own unresolved_because in `agents`), so the console can show an
    undecided part AS undecided rather than omit it, the harness's own rule
    (gate check 195: an omitted part is indistinguishable from one nobody
    thought of). 404, with a distinct detail, when the harness has not been
    built on this server."""
    if not AGENT_HARNESS_PATH.is_file():
        raise HTTPException(
            status_code=404,
            detail="agent harness not built on this server; run scripts/build_agent_harness.py")
    try:
        data = json.loads(AGENT_HARNESS_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        raise HTTPException(status_code=500, detail="agent harness unreadable")
    agents = data.get("agents") if isinstance(data, dict) else None
    agents = agents if isinstance(agents, dict) else {}
    shared = data.get("shared_parts") if isinstance(data, dict) else None
    unresolved = {}
    for name, entry in agents.items():
        if not isinstance(entry, dict):
            continue
        parts = [p for p in HARNESS_PART_NAMES
                 if isinstance(entry.get(p), dict) and entry[p].get("decided") is False]
        if parts:
            unresolved[name] = parts
    return {"agent_count": len(agents), "part_names": list(HARNESS_PART_NAMES),
            "agents": agents, "shared_parts": shared if isinstance(shared, dict) else {},
            "unresolved": unresolved,
            "unresolved_part_count": sum(len(v) for v in unresolved.values())}


@app.get("/runs/{run_id}/activation", dependencies=[Depends(verify_token)])
async def run_activation(run_id: str):
    """Recorded routing and completion evidence, including unavailable old runs."""
    from routing_view import read_activation
    return read_activation(_validated_run_dir(run_id), run_id)


@app.get("/runs/{run_id}/multi-round", dependencies=[Depends(verify_token)])
async def run_multi_round(run_id: str):
    from multi_round import read_saved
    return read_saved(_validated_run_dir(run_id), run_id)


@app.get("/runs/{run_id}/references", dependencies=[Depends(verify_token)])
async def run_references(run_id: str, ref_id: str = None):
    """The passages a run's findings cite (console audit, finding 4).

    Every Finding and every amendment carries `source_refs`, a list of `REF-*`
    (and `WEB-REF-*`) ids, and until now nothing served the passages behind
    them: a reader could see that a finding cited something and could not see
    WHAT, which leaves nothing to do but trust the sentence. A citation that
    cannot be followed is not a citation.

    Reads this run's own `audit/reference_index.json`, written by the reference
    builder during the run. Per entry: `ref_id`, `document_id`, `document_name`,
    `location` (the structural pointer, whatever shape the builder recorded) and
    `text_excerpt`, the passage itself as it was stored, clipped by the builder
    (`reference_builder.excerpt`) and never re-clipped here.

    `ref_id` (optional) returns just that one, which is what a reader following
    a single citation from a finding asks for; `404` when this run's index holds
    no such id, because "this run never cited that" and "that passage is empty"
    are different facts. Without it, the whole index for the run.

    A run whose index does not exist (a run that ended before the index was
    written, or one that predates it) is a `200` with an empty list and
    `index_present: false`, not a `404`: the run is real and the absence is the
    answer.

    The passage text IS content, deliberately: this route exists to show a
    reader the words a finding rests on, which is the one place on this surface
    where content is the point rather than a leak.
    """
    run_dir = _validated_run_dir(run_id)
    path = run_dir / "audit" / "reference_index.json"
    if not path.is_file():
        return {"run_id": run_id, "index_present": False, "count": 0, "references": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        raise HTTPException(status_code=500, detail="reference index unreadable")
    entries = data.get("entries") if isinstance(data, dict) else data
    entries = entries if isinstance(entries, list) else []
    out = []
    for e in entries:
        if not isinstance(e, dict):
            continue
        out.append({
            "ref_id": e.get("ref_id"),
            "document_id": e.get("document_id"),
            "document_name": e.get("document_name"),
            "location": e.get("location"),
            "text_excerpt": e.get("text_excerpt"),
            "input_type": e.get("input_type"),
        })
    if ref_id:
        one = [e for e in out if e["ref_id"] == ref_id]
        if not one:
            raise HTTPException(
                status_code=404,
                detail="this run's reference index holds no %r" % ref_id)
        return {"run_id": run_id, "index_present": True, "count": 1, "references": one}
    return {"run_id": run_id, "index_present": True, "count": len(out), "references": out}


@app.get("/ontology", dependencies=[Depends(verify_token)])
async def ontology_provenance():
    """ontology chain job 1: the first read path the ontology store has ever had.

    The store under ontology/stores/ has been written at the end of every run
    since build B1 and read back by nothing. This route answers the one question
    the store can actually answer: which agent produced which provision under
    which rule, in which run, at which revision. Counts by agent, by rule and by
    run over the whole scope, plus a per-provision list carrying identifiers and
    provenance only, never a provision's own text (a provision's text is content;
    this route's subject is provenance, and ontology_reader.SUMMARY_FIELDS is
    where that boundary is drawn).

    NOT run-scoped: the store is cross-run by construction, the same reasoning
    /harness and /rules/{rule_id} already use for data that does not vary per run.
    Read fresh on every call.

    An EMPTY store is a 200 with zero counts and an empty list, not a 404 and not
    an error: every store in this repository is empty today, because the only
    writer is run-end capture. What this reading is good for, and what it is not,
    is written in ontology_reader's module docstring rather than restated here.

    `provision` (optional) additionally returns every revision of one provision
    id, oldest first, which is what makes the storage layer's supersession
    legible to a human for the first time."""
    import ontology_reader as _reader
    import ontology_store as _store_mod

    store = _reader.read_store(scope=_store_mod.DEFAULT_SCOPE)
    try:
        summary = _reader.provenance_summary(store)
    except OSError:
        raise HTTPException(status_code=500, detail="ontology store unreadable")
    return summary


@app.get("/ontology/provisions/{provision_id:path}", dependencies=[Depends(verify_token)])
async def ontology_provision_history(provision_id: str):
    """One provision's every revision in the default scope, oldest first, as
    provenance summaries (ontology chain job 1). The id is the capture hook's
    composite `<document_id>::<ref_id>` (Q2), which carries a colon pair and so is
    matched as a path parameter.

    404 when the scope holds no such id, which is a real answer rather than an
    empty list: "this store has never held that provision" and "that provision has
    one revision" are different facts and a caller must be able to tell them
    apart."""
    import ontology_reader as _reader
    import ontology_store as _store_mod

    store = _reader.read_store(scope=_store_mod.DEFAULT_SCOPE)
    rows = _reader.provision_history(store, provision_id)
    if not rows:
        raise HTTPException(
            status_code=404,
            detail="no provision with this id in the ontology store (scope %s)"
                   % _store_mod.DEFAULT_SCOPE)
    return {"id": provision_id, "scope": store.scope, "revisions": rows}


@app.get("/ontology/gnn", dependencies=[Depends(verify_token)])
async def ontology_gnn_state():
    """ontology chain job 4: the GNN's persisted state, made visible the way the rest
    of the ontology now is, INCLUDING the absence of a Tier-2 signal.

    Structural metadata only: the state file holds weights and counts and no raw
    content by construction, and this surfaces the counts, never the weights.

    Three fields are always present and always the same, because they are the most
    important thing about this state and must not be a caveat a reader can skip:
    `tier2_signal` is `empty`, `learned_relevance` is `false`, and `ranked_on` says the
    ranking rests on graph structure alone (node type, degree, edges). The engine
    persists and restores its weights across runs, so it does not forget; it has
    learned nothing because there is no signal yet to learn from, which is a different
    thing and the reason nothing here may be presented as learned relevance.

    Not run-scoped. A state that has never been written is a `200` with
    `exists: false`, not a `404`, which is every installation today."""
    # ontology_gnn_state, not ontology_candidates: reading a JSON file of counts
    # must not import torch. It used to, and this route 500'd wherever torch
    # could not load, which the console rendered as an empty section, on the one
    # section whose whole purpose is to stay visible when the state is absent.
    import ontology_gnn_state as _state

    try:
        return _state.state_summary()
    except OSError:
        raise HTTPException(status_code=500, detail="GNN state unreadable")


@app.get("/ontology/candidates", dependencies=[Depends(verify_token)])
async def ontology_candidates_route(top_k: int = 5, min_score: float = 0.0):
    """ontology chain job 4: candidate provision pairs the graph proposes.

    Decision 9's shape: the graph NARROWS (this route), a model DECIDES, and the
    reasoning stays in text. These are pairs that MAY relate; nothing here asserts that
    they do, no Relation record is written from them, and the deterministic baseline
    (job 2) stays beside this rather than being replaced, because both are scored on
    the long-range corpus later and the operator chooses after measurement.

    **What the ranking rests on**: graph structure alone, node type, degree and edges.
    With no Tier-2 signal the GNN has learned nothing, so `ranked_on`,
    `learned_relevance` and `tier2_signal` travel in the response body beside every
    candidate. A candidate set ranked on structure is a real thing and a modest one and
    must never be read as learned relevance.

    `top_k` caps candidates per provision and `min_score` drops weak pairs. An empty
    graph, or one with fewer than two provisions, is a `200` with an empty list, which
    is every installation today."""
    import json as _json
    import ontology_candidates as _cand
    import ontology_gnn as _gnn

    if top_k < 1 or top_k > 50:
        raise HTTPException(status_code=400, detail="top_k must be between 1 and 50")
    gpath = _gnn.DEFAULT_GRAPH_PATH
    try:
        graph = (_json.loads(Path(gpath).read_text(encoding="utf-8"))
                 if Path(gpath).exists() else {"nodes": [], "edges": []})
    except (OSError, ValueError):
        raise HTTPException(status_code=500, detail="ontology graph unreadable")
    return _cand.find_candidates(graph, top_k=top_k, min_score=min_score, device="cpu")


@app.post("/runs/{run_id}/evidence", dependencies=[Depends(verify_token)])
async def run_evidence(run_id: str, body: dict):
    """Classify missed expected defects against a run's saved artifacts.

    When an expected defect is missed, the class and its basis are recorded but
    ONLY the scorer prints them, and the scorer is the one component that may
    open an answer key. A reader therefore could not get the distinction that
    matters most: whether the evidence was in the model's payload (a reasoning
    failure) or never reached it (a pipeline failure).

    This route closes that without ever touching a key. THE CALLER supplies the
    expected entries (`{"expected": [{"unit": ..., "rule": ...}, ...]}`), which
    is the only thing the key contributes; the classification itself reads
    nothing but this run's own `audit/pairing_map.json`,
    `audit/convention_assignment.json`, `logs/call_evidence.jsonl` and the bus
    (`fn_evidence.load_run_artifacts`). No key path is opened, named or
    accepted, and there is no parameter through which one could be.

    Per entry: one of the four classes, the unit ids it resolved to, the
    registry rule id, and `basis`, which names the artifact behind every step,
    so a classification can be checked rather than believed. Plus `counts` over
    the four.

    A POST because the expected entries are the request body, not because it
    changes anything: this route writes nothing at all.
    """
    import fn_evidence as _fe

    run_dir = _validated_run_dir(run_id)
    expected = body.get("expected")
    if not isinstance(expected, list) or not expected:
        raise HTTPException(
            status_code=400,
            detail="'expected' must be a non-empty list of {unit, rule} entries; this "
                   "route never reads an answer key, so the caller supplies them")
    cleaned = [e for e in expected if isinstance(e, dict)]
    if not cleaned:
        raise HTTPException(status_code=400, detail="no usable entry in 'expected'")
    try:
        rows = _fe.classify_missed(cleaned, run_dir)
    except OSError:
        raise HTTPException(status_code=500, detail="run artifacts unreadable")
    return {"run_id": run_id, "count": len(rows), "classes": list(_fe.CLASSES),
            "counts": _fe.summary(rows), "classified": rows}


@app.post("/ontology/conflicts/{conflict_id}/answer", dependencies=[Depends(verify_token)])
async def answer_ontology_conflict(conflict_id: str, body: dict):
    """Record the operator's answer to one ontology-versus-rule conflict.

    Job 3 built the memory and the refusal; there was no way for the operator to
    ANSWER. This is that half, in the same file-backed pattern
    `POST /runs/{run_id}/approval` already uses, and with the same two
    governance constraints.

    FIRST: this route WRITES the answer and nothing else. It never re-runs a
    review, never re-decides a refused pair, never evaluates whether the answer
    was wise. ontology_conflicts.apply_resolutions can read this state, but
    the production review pipeline does not currently call that feedback path.
    A recorded answer is not proof a later review consumed it.

    SECOND: the response says the answer was RECORDED, never that anything was
    resolved. A caller that wants the effect reads `GET /ontology/conflicts`
    afterwards.

    Body: `{"answer": "rule" | "store" | "refuse", "provision_id": ..., "store_rule":
    ..., "rule_id": ...}`. The three sides are optional and are recorded with the
    answer when given, so a reader of the memory later sees what the conflict
    WAS and not only that one was answered. THREE answers, not two: "refuse" (keep
    refusing this pair, produce nothing) is a real decision and is deliberately
    distinguishable from never having answered.

    An unrecognised answer is a `400` and is never written, because a stored
    value this module does not recognise would make every later run either
    re-ask or act on an instruction nobody wrote. Re-answering the same conflict
    is ALLOWED and supersedes, by the storage layer's own rule: an operator may
    change their mind, and the latest answer is what a later run reads.
    """
    import ontology_conflicts as _oc

    answer = str(body.get("answer", "")).strip()
    if answer not in _oc.ANSWERS:
        raise HTTPException(
            status_code=400,
            detail="'answer' must be one of %s; an unrecognised answer is refused "
                   "rather than stored" % (", ".join(_oc.ANSWERS),))
    conflict = {"conflict_id": conflict_id,
                "provision_id": body.get("provision_id"),
                "store_rule": body.get("store_rule"),
                "rule_id": body.get("rule_id")}
    store = _oc.open_store()
    try:
        summary, rejected = _oc.write_resolutions(
            store, {conflict_id: answer}, run_id=str(body.get("run_id") or "operator"),
            conflicts_by_id={conflict_id: conflict})
    except OSError:
        raise HTTPException(status_code=500, detail="ontology store unwritable")
    if rejected or not summary.get("written"):
        raise HTTPException(status_code=400,
                            detail="the answer was refused: %r" % (rejected,))
    return JSONResponse(status_code=202, content={
        "conflict_id": conflict_id,
        "recorded": True,
        "answer": answer,
        "superseded": summary.get("superseded", 0),
        "note": ("recorded, not applied: the next run that meets this conflict applies "
                 "it. This route never re-decides a refused pair."),
    })


@app.get("/ontology/relations", dependencies=[Depends(verify_token)])
async def ontology_relations():
    """The relations between provisions the store holds (console audit, finding 6).

    `ontology_reader.relation_summary` was a finished read path whose only
    callers were gate assertions: the records job 2 writes had no route and so
    no surface. This serves them.

    One row per unordered pair since the merge, each carrying `found_by` (the
    mechanisms that found it), `agreed` (both found it, the pair a reader would
    trust most) and `observations`, one per mechanism, each keeping the
    direction THAT mechanism reported, so a reader can see that the
    cross-reference said one direction and similarity the other.

    `by_method` counts OBSERVATIONS while `relation_count` counts PAIRS, so the
    two do not sum once any pair is agreed; that is the merge working, not an
    inconsistency. `agreed_count` is the figure the old concatenated form could
    not report at all, because agreement showed up there only as duplication.

    Ordering is the operator's one declared rule and nothing more: a pair found
    by both ranks above a pair found by one. No weighting between the two
    mechanisms exists, and none will until the long-range corpus is scored.

    Not run-scoped; the store is cross-run. An empty store is a `200` with an
    empty list, which is every installation today."""
    import ontology_reader as _reader
    import ontology_store as _store_mod

    store = _reader.read_store(scope=_store_mod.DEFAULT_SCOPE)
    try:
        return _reader.relation_summary(store)
    except OSError:
        raise HTTPException(status_code=500, detail="ontology store unreadable")


@app.get("/ontology/conflicts", dependencies=[Depends(verify_token)])
async def ontology_conflicts_route():
    """ontology chain job 3: the conflicts the operator has answered, and the override
    rate, read from the ontology store.

    The operator's decision this serves: when the ontology conflicts with a rule the
    pair is refused in that run and never guessed, the refusals are put to the operator
    together at the end, the next run applies their answers, and the answer is written
    to the ontology so the same conflict is never put to them twice. This route is the
    read side of that memory: which conflicts have been answered, how, and in which run.

    `override_rate` counts answers where the current rule won over the store's memory.
    It carries its own caveat in the response body rather than in documentation alone,
    because at single-operator volume the rate is not statistically meaningful and must
    never be read as a quality measure. It is `null`, never `0.0`, when nothing has been
    answered: "no answers yet" and "never overrode" are different facts.

    Not run-scoped: the memory is cross-run by construction, the same as the rest of the
    store. A store with no answers is a `200` with an empty list, which is every store
    today."""
    import ontology_conflicts as _oc

    store = _oc.open_store()
    try:
        resolutions = _oc.resolutions_in(store)
        rate = _oc.override_rate(store)
    except OSError:
        raise HTTPException(status_code=500, detail="ontology store unreadable")
    answered = [{
        "conflict_id": r.get("conflict_id"),
        "answer": r.get("answer"),
        "provision_id": r.get("provision_id"),
        "store_rule": r.get("store_rule"),
        "rule_id": r.get("rule_id"),
        "answered_in_run": r.get("answered_in_run"),
        "answered_at": r.get("answered_at"),
        "revision": r.get("revision"),
    } for r in sorted(resolutions.values(), key=lambda x: str(x.get("answered_at") or ""))]
    return {"scope": store.scope, "answered_count": len(answered),
            "answered": answered, "override_rate": rate}


@app.get("/rules/{rule_id}", dependencies=[Depends(verify_token)])
async def rule_text(rule_id: str):
    """console fresh-eyes addition: a rule identifier shown anywhere on the
    console (a finding's citation, the developer findings table, a pairing-map
    chip) should be openable, showing the rule as the operator wrote it, not
    just its id. Not run-scoped: this reads the current registry, which can differ from a past run; it is
    the CURRENT registry's content (config/convention_registry.json,
    regenerated at BOOT from input/conventions/).

    Matches by EITHER id the caller might have: the registry's own id
    (CONV-007) or the operator's own id (CONV-A02, recovered from `category`
    the same way finding_record.source_rule_id_for does for a Finding
    record). Whichever one matched, the response is keyed the same way
    everywhere else a rule appears on this surface: `source_rule_id` when the
    registry has one, `id` as the only honest fallback when it does not, so
    there is exactly one naming rule for a rule identifier across the whole
    console, not a third scheme introduced by this route.

    404, with a `detail` distinct from every other 404 on this surface,
    for a rule_id the CURRENT registry does not have: a finding or a
    pairing-map entry can cite a rule id an EARLIER registry had (the
    registry regenerates at BOOT and could differ from what was in force
    when the citing run executed), and that mismatch is itself a fact worth
    a reader seeing, not a silently empty panel."""
    import finding_record as _fr
    registry = _load_convention_registry()
    conventions = registry.get("conventions") or []
    match = None
    wanted_upper = (rule_id or "").upper()
    for c in conventions:
        if not isinstance(c, dict):
            continue
        if c.get("id") == rule_id:
            match = c
            break
        if str(c.get("category") or "").upper() == wanted_upper:
            match = c
            break
    if match is None:
        raise HTTPException(
            status_code=404,
            detail="no rule with this id in the current registry")
    source_rule_id = _fr.source_rule_id_for(match.get("id"), registry)
    return {
        "id": match.get("id"),
        "source_rule_id": source_rule_id,
        "rule": match.get("rule"),
        "severity": match.get("severity"),
        "action": match.get("action"),
        "source_file": match.get("source_file"),
        "source_location": match.get("source_location"),
    }


# ---------------------------------------------------------------------------
# STEP 6: the operator console and its supporting routes.
# ---------------------------------------------------------------------------
@app.get("/console", response_class=HTMLResponse)
async def console():
    """Serve the operator console: one static HTML file, vanilla JavaScript,
    no framework, no build step, no CDN dependency (see scripts/ui/console.html).
    UNGATED like /health, because the browser has no token yet the first time
    it loads this page; the console itself asks for the token before it calls
    any other route.

    CONFLICT NOTE (recorded per CLAUDE.md's "surface conflicts, do not paper
    over them"): the STEP 6 spec's evidence text names this route "GET /".
    Serving it at the bare root collides with an existing, pre-STEP-6 gate
    check (94, productization STEP 3d, its route list updated in api STEP
    B5 when /status/{run_id} and /results/{run_id} were retired): a GET to
    any run-scoped path with a "../.." segment (e.g. "/runs/../..") is
    collapsed by every HTTP client (httpx included, RFC 3986 dot-segment
    removal) into a request for literal path "/" BEFORE it is ever sent,
    client-side, with no way for server code to tell the two apart;
    registering a route at "/" would flip that check's dot-segment
    assertion from 404 (no route matched) to 200 (the console matched),
    which is check_94 as it always existed, not something any step may
    touch (W2: never weaken, skip, or re-order an existing check). Between
    the spec's literal path and W2 (a repository-wide hard rule for every
    step), W2 wins: the console is served at /console instead, still
    ungated, still reachable with one predictable URL, and every run-scoped
    route keeps exactly its pre-existing traversal behavior (proven by
    check_94, unmodified in substance across the api STEP B5 rename) with
    no route ever registered at bare "/" to collide with it. This reasoning
    was never specific to /status or /results in the first place -- the
    client-side collapse applies to any {run_id}-suffixed path, including
    every route built in api STEPs B1-B4 -- so retiring those two names in
    STEP B5 changes nothing about why /console lives where it does."""
    if not UI_CONSOLE_PATH.exists():
        raise HTTPException(status_code=500, detail="console.html missing")
    import localization
    return HTMLResponse(content=localization.console_document(UI_CONSOLE_PATH))


@app.get("/health")
async def health():
    """Unauthenticated liveness probe. Returns a status, this server's declared
    API version (app.version, a plain string constant), and, since api STEP A1,
    the two review facts a caller needs BEFORE it can submit anything: which backend
    profile this server is running ("local" or "cloud") and which review mode a
    submission gets when it names none. Both are short enumerated words, not
    environment values: no SHIMMER_ name or value, no path, no hash, no token,
    no upload limit, no output directory. Startup also exposes the boolean
    privacy-layer switch so the console can explain an inactive layer before
    uploading sensitive files. This is not a complete sensitive-readiness claim.
    Deliberately the one ungated route other than the console shell, for an
    external uptime check that has no token."""
    import sensitivity_layer
    return JSONResponse({"status": "ok", "version": app.version,
                         "backend_profile": _backend_profile(),
                         "default_review_mode": _default_review_mode(),
                         "sensitive_layer_active": sensitivity_layer.is_active()})


@app.get("/runs", dependencies=[Depends(verify_token)])
async def runs():
    """api STEP B1: every run as the complete run-resource object (_run_record),
    oldest submission first. This is the list side of GET /runs/{run_id}: a
    caller reading this route and a caller reading one run's detail parse an
    identical per-run shape, so nothing is lost by reading the list instead of
    polling each run individually. GET /queue, which used to return the same
    JOBS list in a thinner shape, was retired in api STEP B5's route-naming
    pass once this route was already its strict superset."""
    with JOBS_LOCK:
        ordered = [dict(j) for j in sorted(JOBS, key=lambda j: j["submitted_at"])]
    return {"runs": [_run_record(j, RUNS_DIR / j["run_id"]) for j in ordered]}


def _pending_approvals():
    """Scan RUNS_DIR for every run with a pending governed question, NOW
    delegating to _pending_approval_for for the per-run shape (api STEP B5,
    fresh-eyes fix 1e/4d/4e). Before this fix this function had its own,
    independent copy of the pending-vs-answered file check and returned a
    THINNER shape ({run_id, topic, payload, asked_at}, no `message`, no
    `default_on_timeout`, no `timeout_at`) than _pending_approval_for's
    {topic, message, payload, asked_at, default_on_timeout, timeout_at} --
    the same underlying record, described two different ways depending on
    which route a caller asked. _pending_approval_for's OWN docstring has
    claimed since api STEP B1 that this function "delegates to" it, which
    was never true until now; this fix makes that claim true rather than
    correcting the claim to match the old, duplicated code.

    RESPONSE SHAPE CHANGE: GET /approvals' entries gain `message`,
    `default_on_timeout` and `timeout_at` that they did not carry before.
    Nothing is removed; this is additive."""
    out = []
    if not RUNS_DIR.is_dir():
        return out
    for run_dir in sorted(RUNS_DIR.iterdir()):
        if not run_dir.is_dir():
            continue
        pending = _pending_approval_for(run_dir)
        if pending is None:
            continue
        out.append(dict(pending, run_id=run_dir.name))
    return out


@app.get("/approvals", dependencies=[Depends(verify_token)])
async def approvals():
    """Every run currently awaiting a governed decision (see _pending_approvals).
    An empty list is the common case: most runs never hit a governed decision."""
    return {"approvals": _pending_approvals()}


# ---------------------------------------------------------------------------
# STEP 2: rebuild JOBS from disk at IMPORT time (not only when run as __main__),
# so a fresh process (whether started as a server or imported by the gate/tests)
# picks up whatever status.json files a prior process left behind, rewrites any
# "running" job as "interrupted", and clears orphaned staging dirs. This module
# is only ever imported once per process under normal operation.
# ---------------------------------------------------------------------------
_rebuild_jobs_from_disk()


# ---------------------------------------------------------------------------
# STARTUP (only when you run this file directly: python scripts/server.py)
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    # Refuse to start without a token hash: an open dock would let anyone in.
    if not os.environ.get(TOKEN_HASH_ENV):
        print(
            "Refusing to start: the {env} environment variable is not set.\n"
            "Generate a token and its hash with:\n"
            "  python -c \"import secrets, hashlib; t=secrets.token_hex(32); "
            "print(f'Token (give to the collaborator): {{t}}'); "
            "print(f'Hash (set as {env}): {{hashlib.sha256(t.encode()).hexdigest()}}')\"\n"
            "Then set {env} to the printed hash and start the server again."
            .format(env=TOKEN_HASH_ENV),
            file=sys.stderr,
        )
        sys.exit(1)

    # Refuse to start in local mode if the required models are not available.
    local_ok, local_detail = check_local_model_availability()
    if not local_ok:
        print(
            f"Refusing to start in local mode: {local_detail}.\n"
            f"Install the required packages (pip install torch transformers bitsandbytes "
            f"accelerate) and download the models before starting the server.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Echo the resolved configuration so the operator can confirm every knob at a glance.
    print(_config_summary(), file=sys.stderr)
    print(f"Shimmer operator console: {CONSOLE_URL}", file=sys.stderr)
    print(f"Expose it publicly with:  cloudflared tunnel --url http://localhost:{PORT}",
          file=sys.stderr)
    # HOST 0.0.0.0 means listen on all network interfaces, not just localhost. A public
    # tunnel needs this to forward traffic from the internet to your server.
    uvicorn.run(app, host=HOST, port=PORT, log_level=LOG_LEVEL)
