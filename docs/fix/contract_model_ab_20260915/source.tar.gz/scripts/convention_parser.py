"""Convention parser (genesis Part XVIII Section E).

Reads files in input/conventions/, extracts individual rules from markdown
headers / numbered lists / prose, classifies into categories discovered
from the document structure (no predefined list), assigns severity and
action via language cues, writes config/convention_registry.json.

Deterministic. No LLM call. Idempotent: a rerun produces the same IDs
when the source files have not changed.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import text_extract


_TEXT_EXTENSIONS = {".md", ".txt", ".rst", ".log"}
_JSON_EXTENSIONS = {".json"}
# Binary / markup formats: extract plain text via the shared extractor, then
# parse it with the same markdown / list / prose logic as native text files.
_EXTRACT_EXTENSIONS = {".pdf", ".docx", ".html", ".htm"}


_SEVERITY_PATTERNS = [
    ("required",    re.compile(r"\b(must|shall|required|mandatory|prohibited|forbidden|no\s+exception)\b", re.IGNORECASE)),
    ("recommended", re.compile(r"\b(should|recommended|expected|ought to|encouraged)\b", re.IGNORECASE)),
    ("advisory",    re.compile(r"\b(may|consider|optional|where applicable|if appropriate)\b", re.IGNORECASE)),
]


_ACTION_PATTERNS = [
    ("redact",   re.compile(r"\b(redact|mask|conceal|withhold|remove\s+from\s+output|do not (?:print|publish|disclose|reveal))\b", re.IGNORECASE)),
    ("reject",   re.compile(r"\b(reject|do not accept|disallow|prohibit)\b", re.IGNORECASE)),
    ("rephrase", re.compile(r"\b(rephrase|rewrite|replace|substitute|use\s+\S+\s+instead)\b", re.IGNORECASE)),
    ("flag",     re.compile(r"\b(flag|alert|warn|require\s+review|escalate)\b", re.IGNORECASE)),
    ("annotate", re.compile(r"\b(annotate|note|comment|footnote|add\s+citation)\b", re.IGNORECASE)),
]


_DEFAULT_CATEGORY = "unclassified"


@dataclass
class ConventionRule:
    id: str
    category: str
    rule: str
    source_file: str
    source_location: str
    severity: str
    action: str
    subjects: list = field(default_factory=list)
    # D, option 2 (2026-09-11): the operator's own declarations on the heading.
    # scope: the field labels (each optionally with a value) that identify the
    # units the rule governs, [{"label": "class", "value": "a"}, {"label":
    # "device", "value": None}]; requires: the field labels whose absence from a
    # unit in scope is a finding Python decides. Both empty when not declared.
    scope: list = field(default_factory=list)
    requires: list = field(default_factory=list)
    # A CONDITIONAL SUSPENSION: when the condition holds, this rule does not
    # fire. [{"kind": "rule"|"field", "target": str}]. A field condition
    # resolves against the unit the way scope does; a rule condition resolves
    # against the rule it names, and the agent payload then carries both rules
    # together, since a model asked about an exception in isolation from the
    # rule it qualifies gives the wrong answer however well it reads.
    unless: list = field(default_factory=list)
    # TWO-H: set when no severity was declared AND the prose classifier disagreed
    # with the fallback. None otherwise. A guess that decides something is never
    # invisible.
    severity_note: dict = None
    # TWO-G: True only when the operator DECLARED this action (the JSON path).
    # False when it was inferred from prose by the keyword table, which is every
    # markdown convention. The sensitivity layer reads this to refuse deciding a
    # LAW-IV matter on a guess.
    action_declared: bool = False

    def as_dict(self):
        out = {"id": self.id, "category": self.category, "rule": self.rule,
               "source_file": self.source_file, "source_location": self.source_location,
               "severity": self.severity, "action": self.action,
               "action_declared": self.action_declared,
               # TWO-G: the action is written here, so here is where it says it
               # is not consumed. A value that reads like an instruction and
               # changes no outcome is the `unless` defect in another form.
               "action_status": ACTION_NOT_CONSUMED,
               "subjects": self.subjects, "scope": self.scope, "requires": self.requires,
               "unless": self.unless}
        if self.severity_note:
            out["severity_note"] = self.severity_note
        return out


@dataclass
class ConventionRegistry:
    source_files: list = field(default_factory=list)
    conventions: list = field(default_factory=list)

    def as_dict(self):
        return {
            "schema_version": "1.0.0",
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "source_files": self.source_files,
            "conventions": [c.as_dict() for c in self.conventions],
        }


def parse_conventions(project_root: Path) -> ConventionRegistry:
    """Parse every file in input/conventions/ into a registry."""
    in_dir = project_root / "input" / "conventions"
    registry = ConventionRegistry()
    if not in_dir.exists():
        return registry
    seq = [0]
    for path in sorted(in_dir.iterdir()):
        if not path.is_file():
            continue
        ext = path.suffix.lower()
        if ext in _JSON_EXTENSIONS:
            registry.source_files.append(path.name)
            registry.conventions.extend(_parse_json(path, seq))
        elif ext in _TEXT_EXTENSIONS:
            registry.source_files.append(path.name)
            registry.conventions.extend(_parse_text(path, seq))
        elif ext in _EXTRACT_EXTENSIONS:
            registry.source_files.append(path.name)
            registry.conventions.extend(_parse_extracted(path, seq))
        else:
            # No silent drop: an unrecognized file in input/conventions/ warns.
            text_extract.warn_unsupported(path, where="input/conventions")
    return registry


def write_registry(project_root: Path, registry: ConventionRegistry) -> Path:
    path = project_root / "config" / "convention_registry.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(registry.as_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def _next_id(seq):
    seq[0] += 1
    return f"CONV-{seq[0]:03d}"


def _classify_severity(text):
    for label, rx in _SEVERITY_PATTERNS:
        if rx.search(text):
            return label
    return "advisory"


# TWO-H. An UNDECLARED severity must not be silently guessed, now that severity
# decides something (TWO-F: an advisory rule produces its finding and withholds
# its amendment).
#
# Until today the guess was harmless: a heading bracket overrode it wherever one
# existed, and where none existed nothing consumed the value. It is not harmless
# now. A rule with no bracket inherits a GUESSED severity, and an advisory guess
# withholds the amendment silently, which is the one failure an operator cannot
# see.
#
# Measured before choosing, not assumed:
#   - 16 of 44 convention headings across the shipped corpora carry NO severity
#     bracket, so refusing an undeclared severity would break files that were
#     legal yesterday, in two of six corpora.
#   - on the device corpus the prose classifier DISAGREES with the operator's own
#     declaration on 2 of 8 rules (conv-d03, conv-d08), both times guessing
#     advisory for a rule declared required. Both are genuinely required: a
#     validity rule and a prohibition on reviewer speculation.
#   - all 16 bracketless rules happen to guess `required` today, because each
#     contains "must". That is luck, not safety: one worded with "should" or
#     "may" would be downgraded and its amendment withheld with no error.
#
# So: FALL BACK TO REQUIRED, and RECORD THE DISAGREEMENT. Required is the safe
# direction (it produces the amendment rather than withholding it), a bracketless
# file keeps working, and the classifier's error rate becomes visible instead of
# silently load-bearing. Refusing the rule is the other defensible answer, and was
# rejected only because of those 16.
SEVERITY_WHEN_UNDECLARED = "required"


def resolve_severity(declared, rule_text):
    """The severity a rule carries. The operator's declaration, or the fallback.

    TWO-J: THE PROSE GUESS NO LONGER DECIDES ANYTHING. It is computed only to be
    REPORTED, so an operator can see what the wording suggested and judge whether
    to declare something; nothing downstream reads it.

    Measured across all 44 shipped convention rules before deciding:
      - 28 declare a severity. ALL 28 DECLARE `required`. The classifier has
        therefore never once been tested against a declaration it could get
        wrong, so its apparent 22-of-28 accuracy is the accuracy of guessing the
        only value present in the sample. It has no demonstrated ability to
        distinguish anything.
      - the 6 it gets "wrong" are not misfires. NO PATTERN MATCHES AT ALL, and
        the value comes from `_classify_severity`'s trailing `return "advisory"`.
        Both families are declarative rules with no modal verb: a validity
        condition ("is only valid when ... is not calibration-complete") and a
        prohibition stated as a plain declarative ("Findings record ... never a
        guess about cause of fault").
      - flipping that default to `required` would score 28 of 28 and still prove
        nothing, because it would be right BY CONSTANT rather than by reading.

    So the guess is retired from the decision rather than repaired. A severity
    now comes from the operator or from the fallback, and a run never withholds
    an amendment because a regex found no modal verb in a sentence.

    Returns (severity, note). `note` is None when the operator declared one, and
    otherwise records what the prose suggested and that it was NOT used, so the
    fact that a rule is running on the fallback stays visible."""
    if declared:
        return str(declared).strip().lower(), None
    guess = _classify_severity(rule_text or "")
    return SEVERITY_WHEN_UNDECLARED, {
        "declared": None,
        "prose_suggestion": guess,
        "used": SEVERITY_WHEN_UNDECLARED,
        "prose_suggestion_consumed": False,
        "reason": ("no severity was declared on this heading, so it runs on the "
                   "fallback (%r). The wording suggests %r, which is REPORTED and "
                   "NOT USED: prose severity guessing was retired (TWO-J) because "
                   "across the shipped corpora every declared severity is "
                   "`required`, so the classifier was never tested against a value "
                   "it could get wrong, and its six errors all came from matching "
                   "no pattern at all rather than from reading. Declare a severity "
                   "on the heading if this rule should behave differently."
                   % (SEVERITY_WHEN_UNDECLARED, guess)),
    }


# TWO-G. `action` is COMPUTED ON THE REVIEW PATH AND CONSUMED BY NOTHING.
#
# The operator's ruling stands that it has no defensible meaning for a review
# convention: of its five values only `flag` is unambiguous, `redact` belongs to
# the sensitivity layer, `reject` names an outcome a review run does not have,
# and `rephrase` is proposed_text, which is per finding and not a property of a
# rule. This constant is the artifact-facing half of that ruling: every place an
# action is written says plainly that it is not consumed, so it cannot be read as
# an instruction that quietly does nothing, which is the `unless` defect in
# another form.
ACTION_NOT_CONSUMED = (
    "not consumed on the review path: inferred from the rule's wording and "
    "recorded for the reader only. No review behaviour depends on it. The "
    "sensitivity layer is the one consumer of an action value, and it never "
    "reads this field (see redaction_intent below).")


def _classify_action(text):
    for label, rx in _ACTION_PATTERNS:
        if rx.search(text):
            return label
    return "flag"


def _parse_json(path, seq):
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []
    if isinstance(data, dict) and "conventions" in data:
        items = data["conventions"]
    elif isinstance(data, list):
        items = data
    else:
        return []
    out = []
    for i, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        rule = str(item.get("rule") or item.get("text") or "").strip()
        if not rule:
            continue
        subjects = item.get("subjects")
        _sev, _sev_note = resolve_severity(item.get("severity"), rule)
        out.append(ConventionRule(
            id=item.get("id") or _next_id(seq),
            category=str(item.get("category") or _DEFAULT_CATEGORY).strip().lower(),
            rule=rule, source_file=path.name,
            source_location=str(item.get("source_location") or f"item {i+1}"),
            severity=_sev, severity_note=_sev_note,
            action=str(item.get("action") or _classify_action(rule)).lower(),
            # TWO-G: a JSON convention is the ONE path that can DECLARE an
            # action. Everything else infers it from prose. The sensitivity
            # layer must be able to tell the two apart, because an inferred
            # value must never decide a LAW-IV matter.
            action_declared=bool(str(item.get("action") or "").strip()),
            subjects=[str(s).strip().lower() for s in subjects] if isinstance(subjects, list) else [],
            scope=_scope_entries(item.get("scope")),
            requires=[str(s).strip().lower() for s in (item.get("requires") or [])
                      if str(s).strip()] if isinstance(item.get("requires"), list) else [],
            unless=_unless_entries(item.get("unless")),
        ))
    return out


def _unless_entries(raw):
    """Normalise an unless declaration into [{"kind", "target"}], from a JSON
    file giving strings or dicts. The kind is decided by the target's own shape,
    exactly as the heading path decides it, so a rule declared in JSON and one
    declared on a heading mean the same thing."""
    out = []
    for entry in (raw or []) if isinstance(raw, list) else []:
        if isinstance(entry, dict):
            target = str(entry.get("target") or "").strip().lower()
        else:
            target = str(entry).strip().lower()
        if not target:
            continue
        item = {"kind": "rule" if _HEADING_RULE_ID.match(target) else "field",
                "target": target}
        if item not in out:
            out.append(item)
    return out


def _scope_entries(raw):
    """Normalise a scope declaration into [{"label", "value"}]: a list of strings
    ("class", "class=a") or of dicts, as a JSON file or the heading bracket gives it."""
    out = []
    for entry in (raw or []) if isinstance(raw, list) else []:
        if isinstance(entry, dict):
            label, value = entry.get("label"), entry.get("value")
        else:
            label, _, value = str(entry).partition("=")
        label = str(label or "").strip().lower()
        value = str(value).strip().lower() if value not in (None, "") else None
        if label:
            out.append({"label": label, "value": value})
    return out


def _parse_text(path, seq):
    text = path.read_text(encoding="utf-8", errors="replace")
    return _parse_text_lines(text, path.name, seq)


def _parse_text_lines(text, source_name, seq):
    out = []
    current_category = _DEFAULT_CATEGORY
    current_section = "preamble"
    current_severity = None
    current_subjects: list = []
    # True until the first heading that carries the OPERATOR'S OWN rule id
    # (never merely the first heading in the file: a conventions file opened
    # directly with a real, id-less rule section, as check_32's own seed text
    # does, must parse exactly as it always has). While true, a PARAGRAPH is
    # preamble prose, not a rule: this is what fixes the file's title
    # sentence and scope statement being minted as real CONV-* entries. A
    # LIST ITEM is never suppressed by this: an operator who writes a list
    # item under any heading, titled or not, plainly means it as a rule.
    before_first_operator_heading = True
    line_num = 0
    para_buffer = []

    current_scope: list = []
    current_requires: list = []

    def flush(buffer, suppress_paragraph, severity, subjects, location):
        if not buffer or suppress_paragraph:
            return []
        joined = " ".join(b.strip() for b in buffer).strip()
        if not joined:
            return []
        _sev, _sev_note = resolve_severity(severity, joined)
        return [ConventionRule(
            id=_next_id(seq), category=current_category, rule=joined,
            source_file=source_name, source_location=location,
            severity=_sev, severity_note=_sev_note,
            action=_classify_action(joined), subjects=list(subjects),
            scope=[dict(s) for s in current_scope], requires=list(current_requires),
            unless=[dict(u) for u in current_unless],
        )]

    for raw_line in text.splitlines():
        line_num += 1
        line = raw_line.rstrip()
        if _is_markdown_heading(line):
            out.extend(flush(para_buffer, before_first_operator_heading,
                             current_severity, current_subjects,
                             f"line {line_num - len(para_buffer)}"))
            para_buffer = []
            current_category = _normalize_category(line)
            current_section = line.lstrip("# ").strip().lower()
            current_severity, current_subjects = _heading_bracket_tags(line)
            current_scope, current_requires, current_unless = _heading_bracket_declarations(line)
            if before_first_operator_heading and heading_carries_rule_id(line):
                before_first_operator_heading = False
            continue
        if _is_list_item(line):
            out.extend(flush(para_buffer, before_first_operator_heading,
                             current_severity, current_subjects,
                             f"line {line_num - len(para_buffer)}"))
            para_buffer = []
            stripped = _strip_list_marker(line)
            if stripped:
                _sev, _sev_note = resolve_severity(current_severity, stripped)
                out.append(ConventionRule(
                    id=_next_id(seq), category=current_category, rule=stripped,
                    source_file=source_name, source_location=f"line {line_num}",
                    severity=_sev, severity_note=_sev_note,
                    action=_classify_action(stripped), subjects=list(current_subjects),
                    scope=[dict(s) for s in current_scope], requires=list(current_requires),
                    unless=[dict(u) for u in current_unless],
                ))
            continue
        if not line.strip():
            out.extend(flush(para_buffer, before_first_operator_heading,
                             current_severity, current_subjects,
                             f"line {line_num - len(para_buffer)}"))
            para_buffer = []
            continue
        para_buffer.append(line)
    out.extend(flush(para_buffer, before_first_operator_heading, current_severity,
                     current_subjects, f"line {line_num - len(para_buffer) + 1}"))
    return [r for r in out if r.rule and len(r.rule) >= 16]


def _parse_extracted(path, seq):
    # .pdf / .docx / .html / .htm: pull plain text via the shared extractor and
    # run it through the same structural parser as native text files. No temp
    # file is written (the source name is preserved on each rule).
    text = text_extract.extract_text(path)
    if not text.strip():
        return []
    return _parse_text_lines(text, path.name, seq)


def _is_markdown_heading(line):
    return bool(re.match(r"^#{1,6}\s+\S", line))


def _is_list_item(line):
    return bool(re.match(r"^\s*(?:[-*+]|\d+[.)])\s+\S", line))


def _strip_list_marker(line):
    return re.sub(r"^\s*(?:[-*+]|\d+[.)])\s+", "", line).strip()


# _CATEGORY_KEYWORDS was DELETED here (CLASSIFIER-B / WORDS-B). It mapped an
# id-less heading's English words to one of seven buckets, fired on zero of the
# 44 shipped headings, returned order-dependent answers, and still carried the
# "value" defect that once cost a whole corpus its attribution. See
# _normalize_category's docstring for the measurement and the reasoning. A
# heading with no rule id now keeps its own first word, which is read rather
# than interpreted.


_HEADING_RULE_ID = re.compile(r"\bconv-[a-z0-9]+(?:-[a-z0-9]+)*\b", re.IGNORECASE)


def heading_carries_rule_id(line):
    """True when this line is a markdown heading carrying the operator's own
    rule id. This is the parser's load-bearing test (it is what flips
    before_first_operator_heading below), exposed so intake classifies a file
    by the same signal the parser will read it with. Intake used to match two
    exact filenames while this module read every file in the directory
    regardless of name, so a convention file the operator named anything else
    was filed as a document under review and its rules were never compiled.
    Two detectors that must agree are one detector."""
    if not _is_markdown_heading(line):
        return False
    return bool(_HEADING_RULE_ID.search(_normalize_category(line)))


def text_carries_rule_headings(text):
    """True when any line of this text is an operator rule heading."""
    for line in str(text).splitlines():
        if heading_carries_rule_id(line.rstrip()):
            return True
    return False

# The bracket slot an operator already writes on a heading and this parser used
# to discard entirely ("## CONV-D01 , conv-value-in-range [required]"). Every
# [...] on the heading is now read structurally: a token this module already
# knows as a severity label (_SEVERITY_PATTERNS' own three names) sets the
# rule's severity directly, overriding the text-classified default; every
# other token is the operator's own subject tag, carried verbatim (lowercased)
# for the convention-assignment comparison, which contains no subject name of
# its own. No subject vocabulary is declared here: this module only knows the
# bracket SHAPE and the three severity words it already knew.
_HEADING_BRACKET = re.compile(r"\[([^\[\]]+)\]")
_SEVERITY_LABELS = frozenset(label for label, _rx in _SEVERITY_PATTERNS)


def _heading_bracket_tags(heading):
    """(severity_or_none, subjects) read from every [...] on a heading line.

    Each bracket token is lowercased and stripped once; a token equal to one
    of this module's own severity labels (required/recommended/advisory) is
    the severity (the LAST such token wins, matching how a human would read
    a heading left to right), and is excluded from subjects. Every other
    token is a subject, order preserved, duplicates dropped."""
    severity = None
    subjects = []
    for m in _HEADING_BRACKET.finditer(heading):
        token = m.group(1).strip().lower()
        if not token or _DECLARATION_PREFIX.match(token):
            continue  # a scope/requires/unless declaration is not a subject (below)
        shaped = _DECLARATION_SHAPED.match(token)
        if shaped:
            # Declaration-shaped and not one this parser knows. Refuse it rather
            # than absorbing it as a subject: the operator wrote an instruction
            # and it would otherwise be silently reinterpreted.
            raise ConventionDeclarationError(
                "unrecognised declaration [%s: ...] on heading %r.\n"
                "  Recognised declarations: %s.\n"
                "  A declaration this parser cannot honour is refused rather "
                "than read as a subject tag, because a silently reinterpreted "
                "instruction is worse than a rejected one.\n"
                "  If you meant a subject tag, write it without a colon, for "
                "example [conformance].\n"
                "  Note that priority, immutable and outranked_by are the "
                "CONSTITUTION's vocabulary (config/constitution.json) and are "
                "not convention declarations: a convention's force comes from "
                "its category and its own declarations, not from a rank it "
                "gives itself."
                % (shaped.group(1), heading.strip(), _recognised_declarations()))
        if token in _SEVERITY_LABELS:
            severity = token
        elif token not in subjects:
            subjects.append(token)
    return severity, subjects


# D, option 2 (2026-09-11): two more bracket forms, read by their leading word and
# nothing else. "[scope: class, device]" or "[scope: class=a, device]" declares the
# field labels (each optionally pinned to a value) that identify the units the rule
# governs; "[requires: calibration authority signature]" declares the field labels
# whose absence from a unit in scope is a finding Python decides without a model.
# The labels and values are the operator's own words, carried verbatim
# (lowercased) and normalised by the pairing map the way it normalises the
# document's own labels; this module knows the two prefixes and no label at all.
#
# "[unless: <target>]" declares a CONDITIONAL SUSPENSION: when the target holds,
# this rule does not fire. The operator writes one declaration and the parser
# decides which kind of target it is from what is written, because a second
# syntax for a second kind of target is a second thing to learn and to get
# wrong. A target matching the convention id shape (CONV-*, the operator's own
# id form) is a RULE condition, resolved against that rule; anything else is a
# FIELD condition, resolved against the unit the way scope and requires are.
#
# CONV-D01 is the working field case: its own words say a reading must fall in
# the band "UNLESS a locally adjusted range ... has been stated in the entry",
# which survived only as an opaque substring that nothing parsed.
_DECLARATION_PREFIX = re.compile(r"^(scope|requires|unless)\s*:\s*(.*)$")

# A bracket that looks like a declaration (it carries a colon) but whose leading
# word this parser does not know. Absorbing it as a subject tag is what happened
# before: "[overrides: CONV-D02]" became the subject "overrides: conv-d02" and
# nothing said so. A declaration the parser cannot honour is REFUSED, because a
# silently swallowed instruction is worse than a rejected one.
_DECLARATION_SHAPED = re.compile(r"^([a-z][a-z_-]*)\s*:\s*\S")


def _recognised_declarations():
    """The declaration names this parser accepts, read off the regex itself.

    Derived rather than restated, so the error message cannot drift from what
    the parser actually honours. An operator who is stopped without being told
    what IS allowed cannot fix the file, and a hardcoded list in the message
    would eventually name a set the code no longer matches."""
    body = _DECLARATION_PREFIX.pattern
    inner = body[body.index("(") + 1:body.index(")")]
    return ", ".join(inner.split("|"))


class ConventionDeclarationError(ValueError):
    """A heading carries a declaration this parser does not recognise.

    Raised rather than absorbed. The operator wrote an instruction in
    declaration form and the parser cannot honour it, so the run stops here
    instead of proceeding with the instruction silently reinterpreted as a
    subject tag."""


def _heading_bracket_declarations(heading):
    """(scope entries, required labels, unless conditions) from the declaration
    brackets on a heading line.

    scope    [{"label", "value"}] (value None for a bare label)
    requires [label, ...]
    unless   [{"kind": "rule"|"field", "target": str}, ...]

    Comma-separated, order kept, duplicates dropped. A heading without them
    yields ([], [], []). An `unless` target is classified by its own shape: one
    matching the convention id form is a rule condition, anything else is a
    field condition. The parser therefore needs no second syntax and no hint
    from the operator beyond what they already write."""
    scope, requires, unless = [], [], []
    for m in _HEADING_BRACKET.finditer(heading):
        d = _DECLARATION_PREFIX.match(m.group(1).strip().lower())
        if not d:
            continue
        kind, body = d.group(1), d.group(2)
        parts = [p.strip() for p in body.split(",") if p.strip()]
        if kind == "scope":
            for entry in _scope_entries(parts):
                if entry not in scope:
                    scope.append(entry)
        elif kind == "requires":
            for p in parts:
                if p not in requires:
                    requires.append(p)
        else:  # unless
            for p in parts:
                entry = {"kind": "rule" if _HEADING_RULE_ID.match(p) else "field",
                         "target": p}
                if entry not in unless:
                    unless.append(entry)
    return scope, requires, unless


def _normalize_category(heading):
    """The category a convention heading declares.

    An OPERATOR'S OWN RULE ID, when the heading carries one, is the category and
    nothing else is consulted. That id is what finding_record.source_rule_id_for
    reads back so a finding can be attributed to the rule as the operator wrote
    it, and it must survive verbatim.

    It did not, before this: the keyword table below was consulted FIRST, on the
    whole heading, so an operator slug that happened to contain one of a handful
    of English words was silently reclassified. The second corpus this parser was
    ever pointed at wrote "conv-value-in-range", the word "value" matched the
    "value_alignment" bucket (which is about ethics), the operator's id was
    overwritten, and attribution for every finding under that rule was lost.
    Nothing warned.

    CLASSIFIER-B / WORDS-B: THE KEYWORD TABLE IS NOW GONE, deleted rather than
    converted to the five-voter ensemble. Three measurements decided it:

      - it fired on ZERO of the 44 shipped convention headings. Every one
        carries an operator rule id, so the table decided nothing for any corpus
        that exists;
      - its output was ORDER-DEPENDENT and not self-consistent: "Borrowing and
        attribution" returned `citation_style`, not `borrowing`, because
        whichever dict key came first won;
      - it still carried the original defect in the no-id path. "Naming and
        values" returned `value_alignment`, which is the ethics bucket, by the
        same "value" match that lost attribution for a whole corpus.

    Converting it to an ensemble would have built a five-voter decision for a
    decision nothing makes, against reference text nobody has written, replacing
    a wrong answer with an expensive one. Deleting it leaves the heading's own
    first word, which is what the operator actually wrote and is not a guess at
    all: a heading reading "Terminology rules" now yields `terminology` by
    reading it, where the table yielded the same answer by interpreting it.

    If a real corpus ever needs semantic categorisation of id-less headings,
    that is a decision to convert under WORDS-A, with references an operator
    writes. It is not one to infer today.
    """
    h = heading.lstrip("# ").strip().lower()
    own = _HEADING_RULE_ID.search(h)
    if own:
        return own.group(0)
    return h.split()[0] if h else _DEFAULT_CATEGORY
